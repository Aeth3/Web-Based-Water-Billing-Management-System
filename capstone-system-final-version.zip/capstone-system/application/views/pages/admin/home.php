<?php date_default_timezone_set('Asia/Manila'); ?>
<!--################################## Cubic Consumed Chart #########################################-->

            <div class="col-xl-12 col-lg-7" id="">
              
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-gray-900">Monthly sales</h6>
                  <div class="dropdown no-arrow d-none">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-900"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                      aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">

                <div class="form-row">

                  <div class="form-group col-md-6 d-none">
                    <select class="form-control" id="yearsummarys">
                      <option value = "" selected disabled>------Choose Year------</option>
                      <?php 
                     $years = array("2022", "2023", "2024", "2025","2026");

                     foreach ($years as $value) {
                      
                      if ($value == date("Y")) {
                        echo '<option value = "'.$value.'" selected>'.$value.'</option>';
                      }else{
                        echo '<option value = "'.$value.'" >'.$value.'</option>';
                      }

                     }
                      ?>
                      <!-- <option value = "2022" >2022</option>
                      <option value = "2023" >2023</option>
                      <option value = "2024" >2024</option>
                      <option value = "2025" >2025</option>
                      <option value = "2026" >2026</option> -->
                    </select>
                  </div>
              <div class="form-group col-md-6" id="select_year">
                <label for="month_pay">Filter by Year</label>
                  <div class="input-group date">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                    </div>
                    <input type="text" class="form-control" id="yearsummary" value = "<?= date("Y") ?>" required>
                  </div>
              </div>                 


              <div class="form-group col-md-6">
                <label for="" style="color:white">---</label>
                <br>
                    <button type ="button"  class= "btn btn-secondary" id="print-chart-btn"><i class="fas fa-print"></i> PRINT NOW</button>
              </div>  

                </div>
                
                <p class="text-dark" style = "text-decoration: underline" id ="show_annually_earnings"></p>

                  <div class="chart-area" id="div_print">
                    <canvas id="monthly_sale"></canvas>
                  </div>
                </div>
              </div>
            </div>
            
<!--################################## Cubic Consumed Chart End #########################################-->
            
           
         
          
  <?php 
                  $this->db->select('sum(total_amount) as total_amount');
                  $this->db->from('tb_bill');
                  $this->db->where('payment_status',1);
                  $result = $this->db->get();
                  $total_amount = $result->row_array();
                  $total_amount['total_amount'];
  ?>


</body>

</html>

<script>
    

  $(document).ready(function(){

    // $('#print-chart-btn').on('click', function() {
    //   var canvas = document.getElementById("monthly_sale");
    //   var win = window.open();
    //   win.document.write("<br><img src='" + canvas.toDataURL() + "'/>");
    //   win.print();
    //   win.location.reload();
    // });

    $('#print-chart-btn').on('click', function() {
    var canvas = document.querySelector("#monthly_sale");
    var canvas_img = canvas.toDataURL("image/png",1.0); //JPEG will not match background color
    var pdf = new jsPDF('landscape','in', 'letter'); //orientation, units, page size
    pdf.addImage(canvas_img, 'png', .5, 1.75, 10, 5); //image, type, padding left, padding top, width, height
    pdf.autoPrint(); //print window automatically opened with pdf
    //pdf.save('your-filename.pdf');
    var blob = pdf.output("bloburl");
    window.open(blob);
    });
   

    $('#select_year .input-group.date').datepicker({
        startView: 1,
        format: "yyyy",
        minViewMode: "years",
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,        
        autoclose: true,     
        todayHighlight: true,   
        todayBtn: 'linked',
      });

      function numberWithCommas(num) {
      return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
      // $(document).on('change','#year', function() {
      //   alert($('#year').val());
      //   });

    function numberWithCommas(num) {
      return num.toString().replace(/\B(?=(\d{3})+(?!\d))/g, ',');
    }
        // Set new default font family and font color to mimic Bootstrap's default styling
        Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
        Chart.defaults.global.defaultFontColor = ' #000000';

        function number_format(number, decimals, dec_point, thousands_sep) {
          // *     example: number_format(1234.56, 2, ',', ' ');
          // *     return: '1 234,56'
          number = (number + '').replace(',', '').replace(' ', '');
          var n = !isFinite(+number) ? 0 : +number,
            prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
            sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
            dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
            s = '',
            toFixedFix = function(n, prec) {
              var k = Math.pow(10, prec);
              return '' + Math.round(n * k) / k;
            };
          // Fix for IE parseFloat(0.55).toFixed(0) = 0;
          s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
          if (s[0].length > 3) {
            s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
          }
          if ((s[1] || '').length < prec) {
            s[1] = s[1] || '';
            s[1] += new Array(prec - s[1].length + 1).join('0');
          }
          return s.join(dec);
        }

        let months = ["January", "February", "March", "April", "May", "June","July","August","September", "October", "November", "December"];
        let data = [0,0,0,0,0,0,0,0,0,0,0,0];
        let title_header = '';
        // Area Chart Example
        const ctx = document.getElementById("monthly_sale");
        const salesChart = new Chart(ctx, {
          type: 'line',
          data: {
            labels: months,
            datasets: [{
              label: "Earnings",
              lineTension: 0.3,
              backgroundColor: "#FAA5C2",
              borderColor: "#E16389",
              pointRadius: 3,
              pointBackgroundColor: "#E16389",
              pointBorderColor: "#E16389",
              pointHoverRadius: 3,
              pointHoverBackgroundColor: "#a1a1a1",
              pointHoverBorderColor: "#a1a1a1",
              pointHitRadius: 10,
              pointBorderWidth: 2,
              data: data,//[10, 12, 15, 13, 12, 14, 13, 15, 12, 15, 15, 13],
            }],
          },
          options: {
            maintainAspectRatio: false,
            layout: {
              padding: {
                left: 10,
                right: 25,
                top: 25,
                bottom: 0
              }
            },
           
            title: {
                display: true,
                text: title_header
            },
        
            scales: {
              xAxes: [{
                time: {
                  unit: 'date'
                },
                gridLines: {
                  display: false,
                  drawBorder: false
                },
                ticks: {
                  maxTicksLimit: 12
                }
              }],
              yAxes: [{
                ticks: {
                  maxTicksLimit: 5,
                  padding: 10,
                  // Include a dollar sign in the ticks
                  callback: function(value, index, values) {
                    return '₱ ' + number_format(value);
                  }
                },
                gridLines: {
                  color: "rgb(234, 236, 244)",
                  zeroLineColor: "rgb(234, 236, 244)",
                  drawBorder: false,
                  borderDash: [2],
                  zeroLineBorderDash: [2]
                }
              }],
            },
            legend: {
              display: false
            },
            tooltips: {
              backgroundColor: "#a6a092",
              bodyFontColor: "white",
              titleMarginBottom: 10,
              titleFontColor: 'white',
              titleFontSize: 14,
              borderColor: '#dddfeb',
              borderWidth: 1,
              xPadding: 15,
              yPadding: 15,
              displayColors: false,
              intersect: false,
              mode: 'index',
              caretPadding: 10,
              callbacks: {
                label: function(tooltipItem, chart) {
                  var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
                  return datasetLabel + ': ₱' + number_format(tooltipItem.yLabel) ;
                }
              }
            }
          }
        });



        
        $(document).on('change','#yearsummary', function() {
            var yearsummary = $('#yearsummary').val();//$('#yearsummary').find(':selected').val();

          
            $.ajax({
                url: '<?= base_url() ?>admin/get_sales/'+yearsummary+'',
                method: 'GET',
                //dataType:"JSON",
                success: function(response) {
                 
                    //annually
                    //manually
                    
                    var resp = $.parseJSON(response);
                     //alert(resp.annually);
                    months = [];
                    data = [];

                    $.each(resp.manually, function(key, val) {
                        months.push(val.month_name);
                        data.push(val.totalsoldproduct);
                    })

                    salesChart.options.title.text = 'CHART REPORT - ' + yearsummary;

                    salesChart.data.labels = months;
                    salesChart.data.datasets.forEach((dataset) => {
                        dataset.data = data;
                    });

                    salesChart.update();
                   
                    if (resp.annually != 0) {
                      $('#show_annually_earnings').html('TOTAL EARNINGS OF '+yearsummary+': <span class="badge badge-pill badge-success">₱'+numberWithCommas(resp.annually)+'</span>');
                    }else{
                      $('#show_annually_earnings').html('TOTAL EARNINGS OF '+yearsummary+': <span class="badge badge-pill badge-danger">₱'+numberWithCommas(resp.annually)+'</span>');
                    }

                }

            });

          
        });
        var yearsummary_check = $('#yearsummary').val();
        if (yearsummary_check != null) {

          $.ajax({
                url: '<?= base_url() ?>admin/get_sales/'+yearsummary_check+'',
                method: 'GET',
                success: function(response) {
      
                  
                    var resp = $.parseJSON(response);
                    months = [];
                    data = [];

                    $.each(resp.manually, function(key, val) {
                        months.push(val.month_name);
                        data.push(val.totalsoldproduct);
                    })

                    salesChart.options.title.text = 'CHART REPORT - ' + yearsummary_check;

                    salesChart.data.labels = months;
                    salesChart.data.datasets.forEach((dataset) => {
                        dataset.data = data;
                    });

                    salesChart.update();

                    if (resp.annually != 0) {
                      $('#show_annually_earnings').html('TOTAL EARNINGS OF '+yearsummary_check+': <span class="badge badge-pill badge-success">₱'+numberWithCommas(resp.annually)+'</span>');
                    }else{
                      $('#show_annually_earnings').html('TOTAL EARNINGS OF '+yearsummary_check+': <span class="badge badge-pill badge-danger">₱'+numberWithCommas(resp.annually)+'</span>');
                    }
                    //alert(response); 


                }

            });

        }

  });


</script>