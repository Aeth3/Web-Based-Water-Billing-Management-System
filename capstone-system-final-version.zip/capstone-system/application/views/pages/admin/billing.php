

<!--################################## Monthly billing table #########################################-->
<style>
  /* Chrome, Safari, Edge, Opera */
input::-webkit-outer-spin-button,
input::-webkit-inner-spin-button {
  -webkit-appearance: none;
  margin: 0;
}

/* Firefox */
input[type=number] {
  -moz-appearance: textfield;
}
</style>
<?php 
 date_default_timezone_set('Asia/Manila');
?>

<div class="col-xl-12 col-lg-7">
  <div class="card mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-gray-900"> <i class="fas fa-list fa-sm fa-fw mr-2"></i>List of <?= $Page_name ?></h6>

      
    </div>
    
    <div class="card-body">

        <div class="accordion pb-3 d-none" id="accordionExample">
          
          <div class="card">
            <div class="card-header" id="headingOne">
              <h2 class="mb-0">
                <button class="btn btn-secondary btn-block" type="button" data-toggle="collapse" data-target="#collapseOne" aria-expanded="true" aria-controls="collapseOne">
                  --- Filtering ---
                </button>
              </h2>
            </div>

            <div id="collapseOne" class="collapse" aria-labelledby="headingOne" data-parent="#accordionExample">
              <div class="card-body">



              <div class="form-row">

                <div class="form-group col-md-6">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="First_name">First name</span>
                    </div>
                    <input type="text" class="form-control">
                  </div>
                </div>

                <div class="form-group col-md-6">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="Last_name">Last name</span>
                    </div>
                    <input type="text" class="form-control">
                  </div>
                </div>

                <div class="form-group col-md-6" id="month_covered">
                  <div class="input-group date">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                    </div>
                    <input type="text" class="form-control" placeholder= "Month Covered" />
                  </div>
                </div>
                

                <div class="form-group col-md-6" id="simple-date4">
                  <div class="input-daterange input-group">
                    <input type="text" id = "" placeholder= "From" class="input-sm form-control start_date" name="start" />
                    <div class="input-group-prepend">
                      <span class="input-group-text">Date Issued</span>
                    </div>
                    <input type="text" id = "" placeholder= "To" class="input-sm form-control end_date" name="end" />
                  </div>
                </div>

                <div class="form-group col-md-6">
                  <div class="input-group mb-3">
                    <div class="input-group-prepend">
                      <span class="input-group-text" id="Last_name">Meter Number</span>
                    </div>
                    <input type="number" min="1" class="form-control">
                  </div>
                </div>


              </div>

              </div>
            </div>
          </div>

        </div>
        <div class = "pl-3 d-none">
            <button type="button" class="btn btn-outline-primary btn-icon-split" data-toggle="modal" data-target="#addBilling">
                <span class="icon text-light bg-primary">
                    <i class="fas fa-plus-circle"></i>
                </span>
                <span class="text">Add Bill</span>
            </button>
        </div>
        <div class="table-responsive p-3">
            <table class="table align-items-center table-flush table-hover" id="dataTable_billing">
              <thead class="thead-light">
                <tr>
                  <th class= "text-center">Select</th>
                  <th class= "text-center">#</th>
                  <th>Notice for Dsc.</th>
                  <th>Meter Number</th>
                  <th>Full Name</th>
                  <th>Current Reading</th>
                  <th>Previous Reading</th>
                  <th>Arrears</th>
                  <th>Cubic ft Used</th>
                  <th class="width_header">Bill Period</th>
                  <th>Date Issued</th>
                  <th>Payment Status</th>
                  <th>Total Amount</th>
                  <th>Action</th>                  
                </tr>
              </thead>
              <tfoot class="thead-light">
                <tr>
                  <th class= "text-center"></th>
                  <th class= "text-center">#</th>
                  <th>Notice for Dsc.</th>
                  <th>Meter Number</th>
                  <th>Full Name</th>
                  <th>Present Reading</th>
                  <th>Previous Reading</th>
                  <th>Arrears</th>
                  <th>Cubic ft Used</th>
                  <th class="width_header">Bill Period</th>
                  <th>Date Issued</th>
                  <th>Payment Status</th>
                  <th>Total Amount</th>
                  <th>Action</th>                  
                </tr>
              </tfoot>
           


                  
                
                
            </table>
          </div>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="addBilling" data-backdrop="static" data-keyboard="false" tabindex="-1" aria-labelledby="addBillingLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="addBillingLabel">Billing Form</h5>
        <button type="button" class="btn btn-close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
        
            <form class="needs-validation-submit-bill" novalidate>
              <div class="form-row">
                  <div class="form-group col-md-12">
                    <label for="selectConsumer">Select Customer</label>
                    <select style = "width:100%" class="select2-single-placeholder custom-select" name="state" id="selectConsumer" required>
                      <option value="" selected disabled>Select Customer</option>
                      <?php 
                      $this->db->select('*');
                      $this->db->from('tb_consumers as table_a');
                      $this->db->join('tb_credentials as table_c', 'table_a.con_id = table_c.con_id', 'inner');
                      $this->db->where('table_c.cre_status', 1);
                      $query_a = $this->db->get();
                      foreach ($query_a->result_array() as $key => $row_a) {
                        echo '<option value="'.$row_a['con_id'].'">'.$row_a['con_fname'].' '.$row_a['con_lname'].'</option>';
                      }
                      ?>
                    </select>
                    <div class="invalid-tooltip">
                        Required!
                    </div>
                  </div>
              </div>        
       
            <div class="form-row">
                  <div class="form-group col-md-12">
                    <label for="selectMeterNum">Select Meter Number</label>
                    <select style = "width:100%" class="custom-select" name="state" id="selectMeterNum" disabled required>
                      
                    </select>
                  </div>   
              
            </div>

            <div class="form-row" id="show_prev_reading">
               

            </div>            


            <div class="form-row">

            <div class="form-group col-md-6" id="select_month_pay">
                <label for="month_pay">Month Bill Period</label>
                  <div class="input-group date">
                    <div class="input-group-prepend">
                      <span class="input-group-text"><i class="fas fa-calendar"></i></span>
                    </div>
                    <input type="text" class="form-control" id="month_pay" disabled required>
                  </div>
              </div>

              <div class="form-group col-md-6">
                <label for="Arrears">Arrears (*Optional)</label>
                <input type="number" class="form-control" id="Arrears" disabled placeholder="Optional">
              </div>
              
            </div>



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-outline-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-success" id = "submit_bill_btn">Add & Save Now</button>
      </div>

      </form>

    </div>
  </div>
</div>
<!--################################## Monthly billing table End #########################################-->


<style>

    .btn-hover-view:hover {
        background-color: #36b9cc;
        color: white;
    }
    .btn-hover-edit:hover {
        background-color: #f6c23e;
        color: white; 
    }
    .btn-hover-delete:hover {
        background-color: #d52a1a;
        color: white;
    }
    .btn-hover-success:hover {
        background-color: #66bb6a;
        color: white;
    }
    .dt-button.white {
        color: white;
    }
   
    .dt-button.red {
        color: white;
    }
 
    .dt-button.green {
        color: white;
    }
    
    div.dt-button-collection {
    width: 400px;
    }
    
    div.dt-button-collection button.dt-button {
        display: inline-block;
        width: 32%;
    }
    div.dt-button-collection button.buttons-colvis {
        display: inline-block;
        width: 49%;
    }
    div.dt-button-collection h3 {
        margin-top: 5px;
        margin-bottom: 5px;
        font-weight: 100;
        border-bottom: 1px solid #9f9f9f;
        font-size: 1em;
    }
    div.dt-button-collection h3.not-top-heading {
        margin-top: 10px;
    }
    .width_header{
      width: 100px;
    }
</style>

<?php 
if ($Page_name == 'Billing') {
  $d_none = '';
} else {
  $d_none = 'd-none';
}
?>

  <script>
//   $(document).ready(function() {
//     $('#dataTable_billing').DataTable( {
        
//     } );
// } );
function printInvoice(url) {
    newwindow=window.open(url,'name','width=1500,height=1000');
    if (window.focus) {newwindow.focus()}
    return false;
  }
$(document).ready(function () {

      $('#selectConsumer').select2({
        placeholder: "Select a Customer",
        allowClear: true
      }); 

$('.start_date')
    .datepicker({format: "yyyy-mm-dd"})
    .on('changeDate', function (selected) {
        if (typeof selected.date !== 'undefined') {
            var minDate = new Date(selected.date.valueOf());
            $('.end_date').datepicker('setStartDate', minDate);
        }
    });
                
$('.end_date')
    .datepicker({format: "yyyy-mm-dd"})
    .on('changeDate', function (selected) {
        if (typeof selected.date !== 'undefined') {
            var maxDate = new Date(selected.date.valueOf());
            $('.start_date').datepicker('setEndDate', maxDate);
        }
    });

      $('#month_covered .input-group.date').datepicker({
        startView: 2,
        format: "yyyy-mm",
        minViewMode: "months",
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,        
        autoclose: true,     
        todayHighlight: true,   
        todayBtn: 'linked',
      });

      $('#select_month_pay .input-group.date').datepicker({
        startView: 2,
        format: "yyyy-mm",
        minViewMode: "months",
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,        
        autoclose: true,     
        todayHighlight: true,   
        todayBtn: 'linked',
      });

      $('#MeterReading').TouchSpin({
        min: 0,
        max: 10000,
        initval: 0,
        boostat: 5,
        maxboostedstep: 10,
        verticalbuttons: true,
      });

      $('#PreMeterReading').TouchSpin({
        min: 0,
        max: 10000,
        initval: 0,
        boostat: 5,
        maxboostedstep: 10,
        verticalbuttons: true,
      });
      
      $('#Arrears').TouchSpin({
        min: 0,
        max: 10000,
        initval: 0,
        boostat: 5,
        maxboostedstep: 10,
        verticalbuttons: true,
      });

    
<?php 
if ($Page_name == 'Billing') {
  echo 'var payment_status = 0;';
} else {
  echo 'var payment_status = 1;';
}
?>
     var billing_data = $('#dataTable_billing').DataTable({
        "pageLength": 5,
         dom: 'Bfrtip',
        lengthMenu: [
            [5, 10, 20, -1],
            [5, 10, 20, 'All'],
        ],
        autoWidth: false,
        columnDefs: [ {
            orderable: false,
            className: 'select-checkbox',
            targets:   0
        } ],
        select: {
            style:    'multi',
            selector: 'td:first-child'
        },
        order: [[ 1, 'asc' ]],
        "ajax":{
          url:"<?= base_url(); ?>admin/for_consumer/",
          type:"POST",
          data:{all_consumer_bill:'1', payment_status:payment_status},
          dataType:"json"
        },
        'columns': [
              { data: 'Select' },
              { data: '#', className: "uniqueClassName"}, 
              { data: 'Notice_for_Dsc', className: "<?= $d_none ?>"}, 
              { data: 'Meter_Num'}, 
              { data: 'Full_Name'},                   
              { data: 'Current_Reading' },
              { data: 'Previous_Reading'},
              { data: 'Arrears'},                    
              { data: 'Cubic_Meter_Used'},
              { data: 'Month_Covered'},
              { data: 'Date_Issued'},    
              { data: 'Payment_Status'},                                    
              { data: 'Total_Amount' },
              { data: 'Action', className: "<?= $d_none ?>"}
          ],
        "buttons": [
          <?php 
          if ($Page_name == 'Billing') {
          ?>
            {
            text: '<i class="fas fa-plus-circle"></i>\
                    <span class="text">Add Bill</span>',
            className: 'bg-primary text-light',
            action: function ( e, dt, node, config ) {
               $('#addBilling').modal('show');
            }
            },
          <?php
          }
          ?>
            {
                extend: 'pageLength',
                text: 'Rows',
                className: 'black bg-gray-200',
               
            },
            {
                extend: 'print',
                customize: function ( win ) {
                    $(win.document.body)
                        .css( 'font-size', '10pt' )
                        .prepend(
                            '<img src="<?= base_url() ?>img/logo/waterbilling_logo.png" style="position:absolute; top:100; left:280; opacity: 0.2;" />'
                        );
                    $(win.document.body).find('h1').css('text-align', 'center');
                    $(win.document.body).find( 'table' )
                        .addClass( 'compact' )
                        .css( 'font-size', 'inherit' );
                },
                text: '<i class="fas fa-print"></i> Print',
                className: 'white bg-secondary',
                exportOptions: {
                    //columns: ':visible'
                    columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

                }
            },
            {
                extend: 'excelHtml5',
                text: '<i class="fas fa-file-excel"></i> Excel',
                className: 'green bg-success',
                exportOptions: {
                    //columns: ':visible'
                    columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

                }
            },
            {
                extend: 'pdfHtml5',
                customize: function ( doc ) {
                doc.watermark = {text: 'From: Water Billing', color: 'blue', opacity: 0.1};
                },
                text: '<i class="fas fa-file-pdf"></i> PDF',
                className: 'red bg-danger',
                exportOptions: {
                      //columns: ':visible'
                      columns: [ 1, 2, 3, 4, 5, 6, 7, 8, 9, 10, 11, 12]

                }
            },
            {
                extend: 'colvis',
                text: 'Select Column Visibility',
                className: 'red bg-info',
               
            }

				      
			]
            //select: true
    }); 


    $('#selectConsumer').on('change', function() {
            var con_id = $("#selectConsumer").val();
           
            
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{get_meter_number:'1', con_id:con_id},
                    beforeSend: function(){},
                    success:function(data)
                    {
                        //allPrkData.ajax.reload();  
                        $("#selectMeterNum").html(data.meter_num);

                        $("#selectMeterNum").prop('disabled', false);
                        $("#MeterReading").prop('disabled', false);
                        $("#month_pay").prop('disabled', false);
                        $("#Arrears").prop('disabled', false);
                        

                        $("#selectMeterNum").val('0');
                        $("#MeterReading").val('0');
                        $("#PreMeterReading").val('0');
                        $("#month_pay").val('');
                        $("#Arrears").val('0');

                        $("#msg-meterNumber").html('');
                    }
                            
                    });


    });
    //get meter number. if meter number bill exist pop up prev and curr if not pop up only curr 
    $('#selectMeterNum').on('change', function() {
            var meter_id = $("#selectMeterNum").val();
           
            //alert(meter_id);
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{bill_meter_id:'1', meter_id:meter_id},
                    beforeSend: function(){},
                    success:function(data)
                    {
                        
                       
                        if (data.msg == 404) {
                          $("#show_prev_reading").html('<div class="form-group col-md-6 show_prev">\
                                    <label for="PreMeterReading">Previous Reading</label>\
                                    <input type="number" class="form-control" min = "1" id="PreMeterReading" required>\
                                    <span id="msg-meterNumber"></span>\
                                  </div>\
                                  <div class="form-group col-md-6">\
                                    <label for="MeterReading">Current Reading</label>\
                                    <input type="number" class="form-control" min = "1" id="MeterReading" required>\
                                    <span id="msg-meterNumber"></span>\
                                  </div>');
                        }else{
                          $("#show_prev_reading").html('<div class="form-group col-md-6">\
                                    <label for="MeterReading">Current Reading</label>\
                                    <input type="number" class="form-control" min = "1" id="MeterReading" required>\
                                    <span id="msg-meterNumber"></span>\
                                  </div>');
                        }
                     
                    }
                            
                    });


    });
    //get meter number. if meter number bill exist pop up prev and curr if not pop up only curr 


    $("#MeterReadings-deleted").on("keyup change", function(e) {

        var MeterReading = $("#MeterReading").val();
        var con_id = $("#selectConsumer").val();

        if (con_id == null) {
          $("#MeterReading").val('0');
          $("#msg-meterNumber").html('<small class="text-danger">Please select consumer</small>');
        } else {

          $("#msg-meterNumber").html('');
          $("#MeterReading").prop('disabled', false);

          $.ajax({

          url:"<?php echo base_url(); ?>admin/for_consumer/",
          method:"POST",
          dataType:"JSON",
          data:{check_meter_reading:'1', con_id:con_id, meter_reading:MeterReading},
          beforeSend: function(){},
          success:function(data)
          {


              if (data.msg == 303) {

                alert(303);

              } else if (data.msg == 404) {

                alert(404);

              } else if (data.msg == 0) {

                alert(0);

              }

          }
                  
          }); 

        }
  
      

      });

    (function () {
        'use strict'

        var forms_2 = document.querySelectorAll('.needs-validation-submit-bill');

        Array.prototype.slice.call(forms_2)
            .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
                }
                var selectConsumer = $('#selectConsumer').val();
                var selectMeterNum = $('#selectMeterNum').val();
                var MeterReading = $('#MeterReading').val();
                var PreMeterReading = $('#PreMeterReading').val();
                var month_pay = $('#month_pay').val();
                var Arrears = $('#Arrears').val();

                if (selectConsumer == null) {
                  $("#MeterReading").val('0');
                } 
                

                if (selectConsumer == "" || selectMeterNum == "" || MeterReading == 0 || month_pay == "" || PreMeterReading == 0) {
                   
                 
                    form.classList.add('was-validated');
                    

                }else{

                  //alert(1);
             
                    submit_bill_con(selectConsumer,selectMeterNum,PreMeterReading,MeterReading,month_pay,Arrears);

                }
                

                event.preventDefault();
                event.stopPropagation();


            }, false)
            });


        })();

        function submit_bill_con(selectConsumer,selectMeterNum,PreMeterReading,MeterReading,month_pay,Arrears) {
          
          Swal.fire({
          title: 'Are you sure?',
          text: "Click 'Yes' to Submit!",
          icon: 'warning',
          showCancelButton: true,
          confirmButtonColor: '#3085d6',
          cancelButtonColor: '#d33',
          confirmButtonText: 'Yes, submit it!'
        }).then((result) => {
          if (result.isConfirmed) {

              $.ajax({

              url:"<?php echo base_url(); ?>admin/for_consumer/",
              method:"POST",
              dataType:"JSON",
              data:{
                submit_bill:'1', 
                con_id:selectConsumer, 
                meter_id:selectMeterNum, 
                pre_reading:PreMeterReading,
                meter_reading:MeterReading,
                monthly_bill:month_pay, 
                arrears:Arrears 
              },
              beforeSend: function(){
                //submit_bill_btn
                $("#submit_bill_btn").prop('disabled', true);
                $("#submit_bill_btn").html('<span class="spinner-border spinner-border-sm" role="status" aria-hidden="true"></span>Loading...');

              },
              success:function(data)
              {
                $("#submit_bill_btn").prop('disabled', false);
                $("#submit_bill_btn").html('Add & Save Now');
                  //alert(data.msg);
                  if (data.msg == 303) {

                        Swal.fire(
                            'Submmitted!',
                            'Bill added successfully.',
                            'success'
                          );
                      
                      $('#addBilling').modal("hide");   
                      billing_data.ajax.reload();  

                      $('.needs-validation-submit-bill').trigger("reset");
                      $('#selectConsumer').val(null).trigger('change');
                      $('.needs-validation-submit-bill').trigger("reset").removeClass('was-validated');

                  } 
                  else if (data.msg == 404) {

                    Swal.fire(
                            'Opss!',
                            'Bill already exist please check the details!',
                            'error'
                          );  

                  }
                  else {

                        Swal.fire(
                            'Opss!',
                            'Current Reading must greater than previous!',
                            'error'
                          );                    
                  }
                
              }
                      
              });

          }
        });


        }


            //fuction for pay bill start payBillBtn
            //fucntion for pay bill end
            $(document).on('click', '.payBillBtn', function(event){

                var bill_id = $(this).attr("id");  


                Swal.fire({
                title: 'Are you sure?',
                text: "Please click 'Yes' to Pay Bill!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, pay now!'
                }).then((result) => {
                if (result.isConfirmed) {

                
                    
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{payBill:'1', bill_id:bill_id},
                    beforeSend: function(){},
                    success:function(data)
                    {
                      
                        if (data.msg == 303) {

                            Swal.fire(
                                'Paid!',
                                'Bill has been successfully paid!',
                                'success'
                                );

                        } else {

                            alert(1);
                        
                        }
                        billing_data.ajax.reload();  
                    
                    }
                            
                    });
                    
                  
                }
                });

                return false;
     
            });
            //function for delete bill
            $(document).on('click', '.deleteBillBtn', function(event){

                var bill_id = $(this).attr("id");  


                Swal.fire({
                title: 'Are you sure?',
                text: "You won't be able to revert this!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, delete it!'
                }).then((result) => {
                if (result.isConfirmed) {

                
                    
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{deleteBill:'1', bill_id:bill_id},
                    beforeSend: function(){},
                    success:function(data)
                    {
                      
                        if (data.msg == 303) {

                            Swal.fire(
                                'Deleted!',
                                'Bill has been deleted permanently!',
                                'success'
                                );

                        } else {

                            alert(1);
                        
                        }
                        billing_data.ajax.reload();  
                    
                    }
                            
                    });
                    
                  
                }
                });

                return false;
     
            });
            //delete bill
});

  </script>