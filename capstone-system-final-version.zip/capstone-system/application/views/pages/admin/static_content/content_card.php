

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-900"><?= $Page_name ?></h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= base_url() ?>Admin-Home">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"><?= $Page_name ?></li>
            </ol>
          </div>

          <div class="row mb-3">
            <!-- Earnings (Monthly) Card Example -->
            <div class="col-xl-6 col-md-6 mb-4">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Total Earnings</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">₱

                      <span class ="over_all_sale">
                      <?php 
                                      $this->db->select('sum(total_amount) as total_amount');
                                      $this->db->from('tb_bill');
                                      $this->db->where('payment_status',1);
                                      $result = $this->db->get();
                                     echo number_format($result->row_array()['total_amount']);


                      ?>
                      </span>

                    </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <!-- <span class="text-success mr-2"><i class="fa fa-arrow-up"></i> 3.48%</span> -->
                        <span>Since day one</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-calendar fa-2x text-primary"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Earnings (Annual) Card Example -->
            <div class="col-xl-3 col-md-6 mb-4 d-none">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Transaction</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">650</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <!-- <span class="text-success mr-2"><i class="fas fa-arrow-up"></i> 12%</span> -->
                        <span>Since last years</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-hand-holding-usd fa-2x text-success"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- New User Card Example -->
            <div class="col-xl-6 col-md-6 mb-4" style = "cursor:pointer">
              <div class="card h-100">
                <div class="card-body" onclick="window.location='<?= base_url() ?>All-Consumer';">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">All Consumer</div>
                      <div class="h5 mb-0 mr-3 font-weight-bold text-gray-800">Total: 
                        <span class="refresh_total_consumer">
                      <?php 
                        $this->db->select('table_a.*,table_b.*,table_c.*');
                        $this->db->from('tb_consumers as table_a');
                        $this->db->join('tb_prk as table_b', 'table_a.prk_id = table_b.prk_id', 'inner');
                        $this->db->join('tb_credentials as table_c', 'table_a.con_id = table_c.con_id', 'inner');
                        $this->db->order_by("table_c.cre_status", "desc");
                        $this->db->order_by("table_a.con_id", "asc");
                        $query = $this->db->get();
                       echo $query->num_rows();
                      ?>
                      </span>
                      </div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-users fa-2x text-info"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>
            <!-- Pending Requests Card Example -->
            <div class="col-xl-3 col-md-6 mb- d-none">
              <div class="card h-100">
                <div class="card-body">
                  <div class="row no-gutters align-items-center">
                    <div class="col mr-2">
                      <div class="text-xs font-weight-bold text-uppercase mb-1">Pending Requests</div>
                      <div class="h5 mb-0 font-weight-bold text-gray-800">18</div>
                      <div class="mt-2 mb-0 text-muted text-xs">
                        <!-- <span class="text-danger mr-2"><i class="fas fa-arrow-down"></i> 1.10%</span> -->
                        <span>Since yesterday</span>
                      </div>
                    </div>
                    <div class="col-auto">
                      <i class="fas fa-comments fa-2x text-warning"></i>
                    </div>
                  </div>
                </div>
              </div>
            </div>


<script>
  setInterval(
    function () {
        $(".refresh_total_consumer").load(location.href + " .refresh_total_consumer");
        $(".over_all_sale").load(location.href + " .over_all_sale");
    }, 1000);
</script>