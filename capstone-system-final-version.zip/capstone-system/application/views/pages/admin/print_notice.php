<!DOCTYPE html>
                    <html lang="en">
                    <head>
                      <title>NOTICE OF DISCONNECTION</title>
                      <meta charset="utf-8">
                      <meta Full name="viewport" content="width=device-width, initial-scale=1">
                    
                    </head>
                    <body onload="window.print()" onafterprint="self.close()">
                      <style>
                        body {
                            -webkit-print-color-adjust: exact !important;
                        }

                        .alert{
                          padding: 20px;
                          background-color: #D19C97;
                          color: black;
                          border-radius:20px;
                          font-family: Arial, Helvetica, sans-serif;
                              }
                              * {
                            box-sizing: border-box;
                          }
                    
                            /* Create two equal columns that floats next to each other */
                        .column {
                              float: left;
                              width: 50%;
                              padding: 10px;
                              height: 300px; /* Should be removed. Only for demonstration */
                            }
                            .row{
                              margin-bottom: 180px;
                            }
                            
                            /* Clear floats after the columns */
                            .row:after {
                              content: "";
                              display: table;
                              clear: both;
                            }
                            .d-none{
                              display: none;
                            }
                        </style>
             
 
                    <?php 
                      $bill_id = $Param;
                      $this->db->select('table_a.*,table_b.*,table_c.*');
                      $this->db->from('tb_bill as table_a');
                      $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
                      $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');

                      $this->db->where('bill_id', $bill_id);
                      $query = $this->db->get();
                      $row = $query->row_array();

                      $this->db->select('COUNT(table_a.con_id) as bill_no');
                      $this->db->from('tb_bill as table_a');
                      $this->db->where('con_id', $row['con_id']);
                      $this->db->where('meter_id', $row['meter_id']);
                      $query2 = $this->db->get();
                      $row2 = $query2->row_array();

                      $monthly_bill=date_create($row['monthly_bill']);
                      $date_issued=date_create($row['date_issued']);

                      $date = date_create($row['date_issued']);
                      $day = date_format($date,"Y-m-d");
  
                    
                      ?>
                  
             <div class="alert" style = " 
             padding: 10px;
             background-color: #d9534f;
             color: black;
             border-radius:20px;
             font-family: Arial, Helvetica, sans-serif;
             font-size: 15px;
             "> 
             From:  <strong>Water Billing KAPWACO</strong>
             <div style = "text-transform: uppercase;">
             <h2 style = "text-align:center" >NOTICE OF DISCONNECTION</h2>
             
             <p>Full NAME: <strong><?= $row['con_fname'] ?> <?= $row['con_lname'] ?></strong></p>
             <hr>
             <p>ACCOUNT NO. <strong><?= $row['account_id'] ?></strong></p>
             <hr>
             <p>METER NO. <strong><?= $row['meter_num'] ?></strong></p>
             <hr>
             <p>TOTAL AMOUNT TO PAY: <strong>PHP <?= number_format($row['total_amount']) ?></strong></p>
             <hr>
             
             <p>REMARKS: <strong>Please Pay Within 5 days upon receiving the notice of DISCONNECTION.</strong></p>
             <hr>
             </div>

                    </body>
                    </html>