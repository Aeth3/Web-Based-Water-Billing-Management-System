<!DOCTYPE html>
                    <html lang="en">
                    <head>
                      <title>WATER BILL INVOICE</title>
                      <meta charset="utf-8">
                      <meta Full name="viewport" content="width=device-width, initial-scale=1">
                    
                    </head>
                    <body onload="window.print()" onafterprint="self.close()">
                      <style>
                        body {
                            -webkit-print-color-adjust: exact !important;
                        }

                        .alert{
                          padding: 20px;
                          background-color: #D19C97;
                          color: black;
                          border-radius:20px;
                          font-family: Arial, Helvetica, sans-serif;
                              }
                              * {
                            box-sizing: border-box;
                          }
                    
                            /* Create two equal columns that floats next to each other */
                        .column {
                              float: left;
                              width: 50%;
                              padding: 10px;
                              height: 300px; /* Should be removed. Only for demonstration */
                            }
                            .row{
                              margin-bottom: 180px;
                            }
                            
                            /* Clear floats after the columns */
                            .row:after {
                              content: "";
                              display: table;
                              clear: both;
                            }
                            .d-none{
                              display: none;
                            }
                        </style>
             
 
                  
                  <div class="row">
                    <div class="column">
                      <div class="alert" style = " 
                      padding: 10px;
                      background-color: #D19C97;
                      color: black;
                      border-radius:20px;
                      font-family: Arial, Helvetica, sans-serif;
                      font-size: 9px;
                      "> 
                      From:  <strong>Water Billing KAPWACO </strong>
                      <div style = "text-transform: uppercase;">
                      <h2 style = "text-align:center" >WATER BILL</h2>

                      <?php 
                      $bill_id = $Param;
                      $this->db->select('table_a.*,table_b.*,table_c.*');
                      $this->db->from('tb_bill as table_a');
                      $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
                      $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');

                      $this->db->where('bill_id', $bill_id);
                      $query = $this->db->get();
                      $row = $query->row_array();

                      $this->db->select('COUNT(table_a.con_id) as bill_no');
                      $this->db->from('tb_bill as table_a');
                      $this->db->where('con_id', $row['con_id']);
                      $this->db->where('meter_id', $row['meter_id']);
                      $query2 = $this->db->get();
                      $row2 = $query2->row_array();

                      $monthly_bill=date_create($row['monthly_bill']);
                      $date_issued=date_create($row['date_issued']);

                      $date = date_create($row['date_issued']);
                      $day = date_format($date,"Y-m-d");
  
                    
                      ?>
                      <p>BILL NO.<strong> <?= $row2['bill_no'] ?></strong></p>
                      <hr>
                      <p>BILL PERIOD: <strong><?= date_format($monthly_bill,"M. j, Y").' to '.date_format($monthly_bill,"M. t, Y") ?></strong></p>
                      <hr>
                      <p>Full NAME: <strong><?= $row['con_fname'] ?> <?= $row['con_lname'] ?></strong></p>
                      <hr>
                      <p>ACCOUNT NO. <strong><?= $row['account_id'] ?></strong></p>
                      <hr>
                      <p>METER NO. <strong><?= $row['meter_num'] ?></strong></p>
                      <hr>
                      <p>DATE ISSUED: <strong><?= date_format($date_issued,"M. j, Y g:ia") ?></strong></p>
                      <hr>
                      <p>CURRENT READING: <strong> <?= $row['current_reading'] ?></strong> | previous READING: <strong> <?= $row['previous_reading'] ?></strong></p>
                      <hr>
                      <p>CUBIC <span style = "text-transform: lowercase;">ft</span> USED: <strong style = "text-transform: lowercase;"><?= $row['current_reading'] - $row['previous_reading'] ?></strong></p>
                      <hr>
                      <p>ARREARS: <strong><?= $row['arrears'] ?></strong></p>
                      <hr>
                      <p>CURRENT BILL: <strong><?= $row['total_amount'] - $row['arrears'] ?></strong></p>
                      <hr>
                      <p>TOTAL AMOUNT TO PAY: <strong>PHP <?= number_format($row['total_amount']) ?></strong></p>
                      <hr>
                      <p>DUE DATE: <strong><?=   date('M. j, Y', strtotime($day . "+14 days")); ?></strong></p>
                      <hr>
                      <p>REMARKS: <strong>Please Pay the bill before due date.</strong></p>
                      <hr>
                      </div>
                  
                    </div>
                    </div>
                    <div class="column d-none">
                      <div class="alert" style = " 
                      padding: 10px;
                      background-color: #D19C97;
                      color: black;
                      border-radius:20px;
                      font-family: Arial, Helvetica, sans-serif;
                      font-size: 9px;
                      "> 
                      From:  <strong>Water Billing KAPWACO</strong>
                      <div style = "text-transform: uppercase;">
                      <h2 style = "text-align:center" >WATER BILL</h2>
                      <p>BILL NO.<strong> 1</strong></p>
                      <hr>
                      <p>BILL PERIOD: <strong>DEC. 01, 2023 TO DEC. 31, 2023</strong></p>
                      <hr>
                       <p>Full NAME: <strong>KENNETH TANURON</strong></p>
                      <hr>
                      <p>ACCOUNT NO. <strong>#123123213</strong></p>
                      <hr>
                      <p>METER NO. <strong>0001</strong></p>
                      <hr>
                      <p>DATE ISSUED: <strong>DEC. 20, 2023 11:30am</strong></p>
                      <hr>
                      <p>previous READING: <strong> 151</strong> | CURRENT READING: <strong> 151</strong></p>
                      <hr>
                      <p>CUBIC <span style = "text-transform: lowercase;">ft</span> USED: <strong style = "text-transform: lowercase;">1</strong></p>
                      <hr>
                      <p>ARREARS: <strong>200</strong></p>
                      <hr>
                      <p>CURRENT BILL: <strong>200</strong></p>
                      <hr>
                      <p>TOTAL AMOUNT: <strong>₱1000</strong></p>
                      <hr>
                      <p>DUE DATE: <strong>DEC. 31, 2023</strong></p>
                      <hr>
                      <p>REMARKS: <strong>Please Pay the bill before due date.</strong></p>
                      <hr>
                      </div>
                  
                    </div>
                    </div>
                  </div>
                  <div class="row d-none">
                    <div class="column">
                      <div class="alert" style = " 
                      padding: 10px;
                      background-color: #D19C97;
                      color: black;
                      border-radius:20px;
                      font-family: Arial, Helvetica, sans-serif;
                      font-size: 9px;
                      "> 
                      From:  <strong>Water Billing KAPWACO</strong>
                      <div style = "text-transform: uppercase;">
                      <h2 style = "text-align:center" >WATER BILL</h2>
                      <p>BILL NO.<strong> 1</strong></p>
                      <hr>
                      <p>BILL PERIOD: <strong>DEC. 01, 2023 TO DEC. 31, 2023</strong></p>
                      <hr>
                       <p>Full NAME: <strong>KENNETH TANURON</strong></p>
                      <hr>
                      <p>ACCOUNT NO. <strong>#123123213</strong></p>
                      <hr>
                      <p>METER NO. <strong>0001</strong></p>
                      <hr>
                      <p>DATE ISSUED: <strong>DEC. 20, 2023 11:30am</strong></p>
                      <hr>
                      <p>previous READING: <strong> 151</strong> | CURRENT READING: <strong> 151</strong></p>
                      <hr>
                      <p>CUBIC <span style = "text-transform: lowercase;">ft</span> USED: <strong style = "text-transform: lowercase;">1</strong></p>
                      <hr>
                      <p>ARREARS: <strong>200</strong></p>
                      <hr>
                      <p>CURRENT BILL: <strong>200</strong></p>
                      <hr>
                      <p>TOTAL AMOUNT: <strong>₱1000</strong></p>
                      <hr>
                      <p>DUE DATE: <strong>DEC. 31, 2023</strong></p>
                      <hr>
                      <p>REMARKS: <strong>Please Pay the bill before due date.</strong></p>
                      <hr>
                      </div>
                  
                    </div>
                    </div>
                    <div class="column">
                      <div class="alert" style = " 
                      padding: 10px;
                      background-color: #D19C97;
                      color: black;
                      border-radius:20px;
                      font-family: Arial, Helvetica, sans-serif;
                      font-size: 9px;
                      "> 
                      From:  <strong>Water Billing KAPWACO</strong>
                      <div style = "text-transform: uppercase;">
                      <h2 style = "text-align:center" >WATER BILL</h2>
                      <p>BILL NO.<strong> 1</strong></p>
                      <hr>
                      <p>BILL PERIOD: <strong>DEC. 01, 2023 TO DEC. 31, 2023</strong></p>
                      <hr>
                       <p>Full NAME: <strong>KENNETH TANURON</strong></p>
                      <hr>
                      <p>ACCOUNT NO. <strong>#123123213</strong></p>
                      <hr>
                      <p>METER NO. <strong>0001</strong></p>
                      <hr>
                      <p>DATE ISSUED: <strong>DEC. 20, 2023 11:30am</strong></p>
                      <hr>
                      <p>previous READING: <strong> 151</strong> | CURRENT READING: <strong> 151</strong></p>
                      <hr>
                      <p>CUBIC <span style = "text-transform: lowercase;">ft</span> USED: <strong style = "text-transform: lowercase;">1</strong></p>
                      <hr>
                      <p>ARREARS: <strong>200</strong></p>
                      <hr>
                      <p>CURRENT BILL: <strong>200</strong></p>
                      <hr>
                      <p>TOTAL AMOUNT: <strong>₱1000</strong></p>
                      <hr>
                      <p>DUE DATE: <strong>DEC. 31, 2023</strong></p>
                      <hr>
                      <p>REMARKS: <strong>Please Pay the bill before due date.</strong></p>
                      <hr>
                      </div>
                  
                    </div>
                    </div>
                  </div>
                    </body>
                    </html>