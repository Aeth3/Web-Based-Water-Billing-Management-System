<section style="width:100%" class="update_profile_consumer">
  <div class="container" >

    <div class="row">
      <div class="col-lg-4">
        <div class="card mb-4">
          <div class="card-body text-center">
                <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                   if ($value['con_avatar'] == 'Boy') {
                    echo '<img src="'.base_url().'img/boy.png" alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">;
                    ';
                   }elseif($value['con_avatar'] == 'Girl'){
                    echo '<img src="'.base_url().'img/girl.png" alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">;
                    ';
                   }elseif($value['con_avatar'] == 'Man'){
                    echo '<img src="'.base_url().'img/man.png" alt="avatar" class="rounded-circle img-fluid" style="width: 150px;">;
                    ';
                   }

                  }
                  ?>

            <h5 class="my-3">
                <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['con_fname'].' '.$value['con_lname'];

                  }
                  ?>              
            </h5>
            <div class="d-flex justify-content-center mb-2">
              <button type="button" class="btn btn-outline-dark ms-1" data-toggle="modal" data-target="#exampleModal_UpdateProfile">EDIT PROFILE</button>
            </div>
          </div>
        </div>
        <div class="card mb-4 mb-lg-0">
          <div class="card-header text-center">
            <h4>Credentials</h4>
          </div>
          <div class="card-body p-0">
            <ul class="list-group list-group-flush rounded-3">

              <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                <i class="fas fa-user fa-lg" style="color: #333333;"></i>
                <p class="mb-0">
                 <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['cre_username'];

                  }
                  ?>
                </p>
              </li>
              <li class="list-group-item d-flex justify-content-between align-items-center p-3">
                <i class="fas fa-lock fa-lg" style="color: #333333;"></i>
                <p class="mb-0">
                  <i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i><i class="fas fa-asterisk"></i>
                  <button type="button" data-toggle="modal" data-target="#exampleModal_UpdateCredentials" class="btn btn-outline-warning btn-sm"><i class="fas fa-edit"></i></button>
                </p>
              </li>
             
            </ul>
          </div>
        </div>
      </div>
      <div class="col-lg-8">
        <div class="card mb-4">
          <div class="card-body">
          <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Account ID</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">
                  <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['account_id'];

                  }
                  ?>
                </p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Full Name</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">
                  <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['con_fname'].' '.$value['con_lname'];

                  }
                  ?>
                </p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Purok</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">
                 <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['prk_name'];

                  }
                  ?>
                </p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Email</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">
                 <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['con_email'];

                  }
                  ?>
                </p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Mobile Number</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0">
                 <?php
                  foreach ($Consumer_Info as $key => $value) {
                  
                    echo $value['con_cpnumber'];

                  }
                  ?>
                </p>
              </div>
            </div>
            <hr>
            <div class="row">
              <div class="col-sm-3">
                <p class="mb-0">Meter Number</p>
              </div>
              <div class="col-sm-9">
                <p class="text-muted mb-0 refresh_meter_number">
                  <?php
                  // foreach ($Consumer_Info as $key => $value) {
                  
                  //   echo $value['meternum_owner'];

                  // }
                  $this->db->select('

                  table_a.*, 
                  table_b.*, 
                  table_b.meter_id as tb_meterid, 
                  table_b.meter_id as ta_meterid
  
                  ');
                  $this->db->from('tb_owner_meter as table_a');
                  $this->db->join('tb_meter_num as table_b','table_a.meter_id = table_b.meter_id');
                  $this->db->where('table_a.con_id',$value['con_id']);
                  $query = $this->db->get();
                  foreach ($query->result_array() as $key => $m) {
                    
                    if ($m['m_status'] == 0) {
                      echo $m['meter_num'].' <a href="#" id = "'.$m['meter_id'].'" class="btn btn-danger btn-circle btn-sm disc_meter">
                      Disconnect meter number <i class="fas fa-exclamation-triangle"></i>
                  </a></br></br>';
                    }else{
                      echo $m['meter_num'].' <a href="#" id = "'.$m['meter_id'].'" class="btn btn-success btn-circle btn-sm activate_meter">
                      Activate meter <i class="fas fa-check-square"></i>
                  </a></br></br>';
                    }

                          
                  }
                  ?>
                </p>
              </div>
            </div>
            
          </div>
        </div>
       
      </div>
    </div>
  </div>
</section>


<!-- Modal -->
<div class="modal fade" id="exampleModal_UpdateCredentials" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Change Password</h5>
        <button type="button" class="close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <form id="change_pass_consumer" class="g-3 needs-validation-changepass" novalidate>

        <div class="form-row">
        <input type="hidden" class="form-control" id="con_id"  value ="<?= $value['con_id'] ?>"required>

          <div class="form-group col-md-12">
            <label for="new_password">New Password</label>
            <input type="text" class="form-control" id="new_password" required>
          </div>

        </div>

      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" class="btn btn-capstone">Save & Change</button>
      </div>
       </form>
    </div>
  </div>
</div>

<!-- Modal -->
<div class="modal fade" id="exampleModal_UpdateProfile" tabindex="-1" aria-labelledby="exampleModal_UpdateProfileLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModal_UpdateProfileLabel">Update Profile</h5>
        <button type="button" class="btn close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">

      <form id="update_profile" class="g-3 needs-validation-update-profile" novalidate>

      <input type="hidden" class="form-control" id="con_id"  value ="<?= $value['con_id'] ?>"required>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="con_fname">First name</label>
            <input type="text" class="form-control" id="con_fname"  value ="<?= $value['con_fname'] ?>"required>
          </div>
          <div class="form-group col-md-6">
            <label for="con_lname">Last name</label>
            <input type="text" class="form-control" id="con_lname"  value ="<?= $value['con_lname'] ?>"required>
          </div>
        </div>
        <div class="form-row">
          <div class="form-group col-md-6">
            <label for="con_email">Email</label>
            <input type="email" class="form-control" id="con_email" value ="<?= $value['con_email'] ?>">
          </div>
          <div class="form-group col-md-6">
            <label for="con_cpnumber">Contact No.</label>
            <input type="text" class="form-control" id="con_cpnumber"  value ="<?= $value['con_cpnumber'] ?>" pattern="[0-9]{11}" placeholder = "Format: 09123123123" required>
            <div class="invalid-tooltip">
                 Invalid Format!
            </div>
          </div>
        </div>
      



      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Cancel</button>
        <button type="submit" class="btn btn-capstone">Save & Update now</button>
      </div>

      </form>
    </div>
  </div>
</div>
<!-- <form action="<?php //echo base_url() ?>admin/for_consumer/" method="post">

<button type="submit" name = "sample_dummy">print</button>
</form> -->
<script>
        (function () {
        'use strict'


         var forms = document.querySelectorAll('.needs-validation-update-profile');

        Array.prototype.slice.call(forms)
            .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                }

                var con_id = $('#con_id').val();
                var con_fname = $('#con_fname').val();
                var con_lname = $('#con_lname').val();
                var con_email = $('#con_email').val();
                var con_cpnumber = $('#con_cpnumber').val();

                if (con_id == "" || con_fname == "" || con_lname == "" || con_cpnumber == "") {
                   
                 
                    form.classList.add('was-validated');
                    

                }else{
                
                    updateProfile(con_id,con_fname,con_lname,con_email,con_cpnumber);
                    

                }
                

                event.preventDefault();
                event.stopPropagation();


            }, false)
            });

        })();

      function updateProfile(con_id,con_fname,con_lname,con_email,con_cpnumber) {

      
                    $.ajax({

                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{update_profile:'1', con_id:con_id,con_fname:con_fname,con_lname:con_lname,con_email:con_email,con_cpnumber:con_cpnumber},
                    beforeSend: function(){},
                    success:function(data)
                    {
                      $(".update_profile_consumer").load(location.href + " .update_profile_consumer"); 
                      $('#exampleModal_UpdateProfile').modal('hide');
                       if (data.msg == 303) {

                        Swal.fire({
                            icon: 'success',
                            title: 'Profile Updated Successfully',
                            showConfirmButton: true,
                            allowOutsideClick: false
                            });

                        } else {

                            Swal.fire({
                            icon: 'error',
                            title: 'Please try again',
                            showConfirmButton: true,
                            allowOutsideClick: false
                            });
                        
                        }
                       
                    }
                            
                    });

                   
        
      }

      (function () {
        'use strict'


         var forms2 = document.querySelectorAll('.needs-validation-changepass');

        Array.prototype.slice.call(forms2)
            .forEach(function (form2) {
            form2.addEventListener('submit', function (event) {
                if (!form2.checkValidity()) {
                event.preventDefault();
                event.stopPropagation();
                }

                var con_id = $('#con_id').val();
                var new_password = $('#new_password').val();


                if (con_id == "" || new_password == "" ) {
                   
                 
                    form2.classList.add('was-validated');
                    

                }else{
                
                    changePass(con_id,new_password);
                    

                }
                

                event.preventDefault();
                event.stopPropagation();


            }, false)
            });

  function changePass(con_id,new_password) {

            $.ajax({

                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{change_pass:'1', con_id:con_id,new_password:new_password},
                    beforeSend: function(){},
                    success:function(data)
                    {

                      $('#exampleModal_UpdateCredentials').modal('hide');
                      $('#change_pass_consumer').trigger("reset").removeClass('was-validated');
                       if (data.msg == 303) {

                        Swal.fire({
                            icon: 'success',
                            title: 'Password Change Successfully',
                            showConfirmButton: true,
                            allowOutsideClick: false
                            });

                        } else {

                            Swal.fire({
                            icon: 'error',
                            title: 'Please try again',
                            showConfirmButton: true,
                            allowOutsideClick: false
                            });
                        
                        }
                       
                    }
                            
                    });

   }


        })();


          //function for disc meter num
            $(document).on('click', '.disc_meter', function(event){

                var meter_id = $(this).attr("id");  
              

                Swal.fire({
                title: 'Are you sure?',
                text: "Click 'Yes' to disconnect meter!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, disconnect it!'
                }).then((result) => {
                if (result.isConfirmed) {

                
                    
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{disconnect_meter:'1', meter_id:meter_id},
                    beforeSend: function(){},
                    success:function(data)
                    {
                      
                        if (data.msg == 303) {

                            Swal.fire(
                                'Disconnected!',
                                'Meter Number has been Disconnected Successfully!',
                                'success'
                                );

                        } else {

                            alert(1);
                        
                        }

                      setInterval(
                          function () {

                              $(".refresh_meter_number").load(location.href + " .refresh_meter_number");
                             
                          }, 1000);                        
                    
                    }
                            
                    });
                    
                  
                }
                });

                return false;
     
            });
//here
            $(document).on('click', '.activate_meter', function(event){

                var meter_id = $(this).attr("id");  
              

                Swal.fire({
                title: 'Are you sure?',
                text: "Click 'Yes' to activate meter!",
                icon: 'warning',
                showCancelButton: true,
                confirmButtonColor: '#3085d6',
                cancelButtonColor: '#d33',
                confirmButtonText: 'Yes, activate it!'
                }).then((result) => {
                if (result.isConfirmed) {

                
                    
                $.ajax({
                    url:"<?php echo base_url(); ?>admin/for_consumer/",
                    method:"POST",
                    dataType:"JSON",
                    data:{activate_meter:'1', meter_id:meter_id},
                    beforeSend: function(){},
                    success:function(data)
                    {
                      
                        if (data.msg == 303) {

                            Swal.fire(
                                'Disconnected!',
                                'Meter Number has been Activated Successfully!',
                                'success'
                                );

                        } else {

                            alert(1);
                        
                        }

                      setInterval(
                          function () {

                              $(".refresh_meter_number").load(location.href + " .refresh_meter_number");
                             
                          }, 1000);                        
                    
                    }
                            
                    });
                    
                  
                }
                });

                return false;
     
            });
//here
            //disc disc meter num
</script>