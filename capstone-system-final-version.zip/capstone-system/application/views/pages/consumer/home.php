

        <!-- Container Fluid-->
        <div class="container-fluid" id="container-wrapper">
          <div class="d-sm-flex align-items-center justify-content-between mb-4">
            <h1 class="h3 mb-0 text-gray-900"><?= $Page_name ?></h1>
            <ol class="breadcrumb">
              <li class="breadcrumb-item"><a href="<?= base_url() ?>">Home</a></li>
              <li class="breadcrumb-item active" aria-current="page"><?= $Page_name ?></li>
            </ol>
          </div>

          <div class="row mb-3">


<!--################################## Monthly Payment Chart #########################################-->

<div class="col-xl-12 col-lg-7">


  <div class="form-row">
    <div class="form-group col-md-6">
      <select class="form-control form-control-lg" id = "meter_id">
        <option vaue = "" selected disabled style = "text-align:center">------SELECT METER NUMBER------</option>

       
        <?php
                        $this->db->select('*');
                        $this->db->from('tb_owner_meter as table_a');
                        $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');
                        $this->db->where('con_id', $this->session->con_id);
                        $query = $this->db->get();
                        $row = $query->result_array(); 
                        foreach ($query->result_array() as $key => $value) {
                            echo '<option value="'.$value['meter_id'].'" selected>'.$value['meter_num'].'</option>';
                        }
        ?>
      </select>
    </div>
    <div class="form-group col-md-6" id="select_year">
          <div class="input-group date">
            <div class="input-group-prepend">
               <span class="input-group-text"><i class="fas fa-calendar"></i></span>
            </div>
            <input type="text" class="form-control form-control-lg" id="yearsummary" value = "<?= date("Y") ?>" required>
          </div>
    </div>

    <div class="form-group col-md-2 d-none">
      <button type="button" class="btn btn-capstone btn-lg btn-block">RESET</button>
    </div>
  </div>

  <div class="card mb-4">
    <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
      <h6 class="m-0 font-weight-bold text-gray-900">Monthly Payment</h6>
      <div class="dropdown no-arrow d-none">
        <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
          aria-haspopup="true" aria-expanded="false">
          <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-900"></i>
        </a>
        <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
          aria-labelledby="dropdownMenuLink">
          <div class="dropdown-header">Dropdown Header:</div>
          <a class="dropdown-item" href="#">Action</a>
          <a class="dropdown-item" href="#">Another action</a>
          <div class="dropdown-divider"></div>
          <a class="dropdown-item" href="#">Something else here</a>
        </div>
      </div>
    </div>
    <div class="card-body">
    <p class="text-dark" style = "text-decoration: underline" id ="show_annually_earnings"></p>
      <div class="chart-area">
        <canvas id="monthly_payment"></canvas>
      </div>
    </div>
  </div>
</div>

<!--################################## Monthly Payment Chart End #########################################-->



<!--################################## Cubic Consumed Chart #########################################-->
            <div class="col-xl-12 col-lg-7">
              <div class="card mb-4">
                <div class="card-header py-3 d-flex flex-row align-items-center justify-content-between">
                  <h6 class="m-0 font-weight-bold text-gray-900">Monthly Cubic Consumed</h6>
                  <div class="dropdown no-arrow d-none">
                    <a class="dropdown-toggle" href="#" role="button" id="dropdownMenuLink" data-toggle="dropdown"
                      aria-haspopup="true" aria-expanded="false">
                      <i class="fas fa-ellipsis-v fa-sm fa-fw text-gray-900"></i>
                    </a>
                    <div class="dropdown-menu dropdown-menu-right shadow animated--fade-in"
                      aria-labelledby="dropdownMenuLink">
                      <div class="dropdown-header">Dropdown Header:</div>
                      <a class="dropdown-item" href="#">Action</a>
                      <a class="dropdown-item" href="#">Another action</a>
                      <div class="dropdown-divider"></div>
                      <a class="dropdown-item" href="#">Something else here</a>
                    </div>
                  </div>
                </div>
                <div class="card-body">
                  <div class="chart-area">
                    <canvas id="cubic_consumed"></canvas>
                  </div>
                </div>
              </div>
            </div>
<!--################################## Cubic Consumed Chart End #########################################-->
            
          <?php 
          
          $this->db->select('
          table_a.*, 
          table_b.*, 
          table_c.*
          ');
          $this->db->from('tb_bill as table_a');
          $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
          $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');
          $this->db->where('table_b.con_id', $this->session->con_id);
          $this->db->where('table_a.payment_status', 0);
          $this->db->order_by("bill_id", "desc");
          //$this->db->limit(2);
          $query = $this->db->get();

        
          $output = '';
          $price = '';
          $result = false;

          foreach ($query->result() as $key => $v) {
             

            $this->db->select('*');
            $this->db->from('tb_meter_num');
            $this->db->where('meter_id', $v->meter_id);
            $query = $this->db->get();
            $row = $query->row_array();
           
            //print_r($row);
            //echo $v->meter_num.'<br>';
           
            if ($row['meter_id'] == $v->meter_id) {
               
                 $cubicMeter=$v->current_reading - $v->previous_reading;
                if ($cubicMeter >= 42) {
                    $result = true;
                   $output .= $v->meter_num.',';
                   $price .= 'Meter no. '.$v->meter_num.' - ₱'.number_format($v->total_amount).'<br>';
                }


            }


          }
          // echo 'Your cubic '.$output.' average for this month is bad. Please contact Adminstrator</br>';
          // echo 'Your payment for this month '.$price.'';


          ?> 
         
          
  
  <script>  
  $(document).ready(function(){

      $('#select_year .input-group.date').datepicker({
        startView: 1,
        format: "yyyy",
        minViewMode: "years",
        changeMonth: true,
        changeYear: true,
        showButtonPanel: true,        
        autoclose: true,     
        todayHighlight: true,   
        todayBtn: 'linked',
      });



// Set new default font family and font color to mimic Bootstrap's default styling
Chart.defaults.global.defaultFontFamily = 'Nunito', '-apple-system,system-ui,BlinkMacSystemFont,"Segoe UI",Roboto,"Helvetica Neue",Arial,sans-serif';
Chart.defaults.global.defaultFontColor = '#000000';

function number_format(number, decimals, dec_point, thousands_sep) {
  // *     example: number_format(1234.56, 2, ',', ' ');
  // *     return: '1 234,56'
  number = (number + '').replace(',', '').replace(' ', '');
  var n = !isFinite(+number) ? 0 : +number,
    prec = !isFinite(+decimals) ? 0 : Math.abs(decimals),
    sep = (typeof thousands_sep === 'undefined') ? ',' : thousands_sep,
    dec = (typeof dec_point === 'undefined') ? '.' : dec_point,
    s = '',
    toFixedFix = function(n, prec) {
      var k = Math.pow(10, prec);
      return '' + Math.round(n * k) / k;
    };
  // Fix for IE parseFloat(0.55).toFixed(0) = 0;
  s = (prec ? toFixedFix(n, prec) : '' + Math.round(n)).split('.');
  if (s[0].length > 3) {
    s[0] = s[0].replace(/\B(?=(?:\d{3})+(?!\d))/g, sep);
  }
  if ((s[1] || '').length < prec) {
    s[1] = s[1] || '';
    s[1] += new Array(prec - s[1].length + 1).join('0');
  }
  return s.join(dec);
}
//for monthly chart start
let months = ["January", "February", "March", "April", "May", "June","July","August","September", "October", "November", "December"];
let data_monthly = [0,0,0,0,0,0,0,0,0,0,0,0];
// Bar Chart Example
const month_ctx = document.getElementById("monthly_payment");
const monthlyChart = new Chart(month_ctx, {
  type: 'bar',
  data: {
    labels: months,
    datasets: [{
      label: "Amount",
      backgroundColor: "#FAA5C2",
      hoverBackgroundColor: "#E16389",
      borderColor: "#4e73df",
      data: data_monthly,
    }],
  },
  options: {
    maintainAspectRatio: false,
    layout: {
      padding: {
        left: 10,
        right: 25,
        top: 25,
        bottom: 0
      }
    },
    scales: {
      xAxes: [{
        time: {
          unit: 'month'
        },
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          maxTicksLimit: 12
        },
        maxBarThickness: 25,
      }],
      yAxes: [{
        ticks: {
          min: 0,
          maxTicksLimit: 5,
          padding: 10,
          // Include a dollar sign in the ticks
          callback: function(value, index, values) {
            return '₱' + number_format(value);
          }
        },
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      titleMarginBottom: 10,
      titleFontColor: '#6e707e',
      titleFontSize: 14,
      backgroundColor: "rgb(255,255,255)",
      bodyFontColor: "#000000",
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + ': ₱' + number_format(tooltipItem.yLabel);
        }
      }
    },
  }
});
//for monthly chart end


//for cubic meter start

// Area Chart Example
let months_cubic = ["January", "February", "March", "April", "May", "June","July","August","September", "October", "November", "December"];
let data_monthly_cubic = [0,0,0,0,0,0,0,0,0,0,0,0];
const ctx_cubic = document.getElementById("cubic_consumed");
const myLineChart_cubic = new Chart(ctx_cubic, {
  type: 'line',
  data: {
    labels: months,
    datasets: [{
      label: "Cubic",
      lineTension: 0.3,
      backgroundColor: "#FAA5C2",
      borderColor: "#E16389",
      pointRadius: 3,
      pointBackgroundColor: "#E16389",
      pointBorderColor: "#E16389",
      pointHoverRadius: 3,
      pointHoverBackgroundColor: "#a1a1a1",
      pointHoverBorderColor: "#a1a1a1",
      pointHitRadius: 10,
      pointBorderWidth: 2,
      data: data_monthly_cubic,
    }],
  },
  options: {
    maintainAspectRatio: false,
    layout: {
      padding: {
        left: 10,
        right: 25,
        top: 25,
        bottom: 0
      }
    },
    scales: {
      xAxes: [{
        time: {
          unit: 'date'
        },
        gridLines: {
          display: false,
          drawBorder: false
        },
        ticks: {
          maxTicksLimit: 12
        }
      }],
      yAxes: [{
        ticks: {
          maxTicksLimit: 5,
          padding: 10,
          // Include a dollar sign in the ticks
          callback: function(value, index, values) {
            return number_format(value) + ' ft³';
          }
        },
        gridLines: {
          color: "rgb(234, 236, 244)",
          zeroLineColor: "rgb(234, 236, 244)",
          drawBorder: false,
          borderDash: [2],
          zeroLineBorderDash: [2]
        }
      }],
    },
    legend: {
      display: false
    },
    tooltips: {
      backgroundColor: "#fc544b",
      bodyFontColor: "white",
      titleMarginBottom: 10,
      titleFontColor: 'white',
      titleFontSize: 14,
      borderColor: '#dddfeb',
      borderWidth: 1,
      xPadding: 15,
      yPadding: 15,
      displayColors: false,
      intersect: false,
      mode: 'index',
      caretPadding: 10,
      callbacks: {
        label: function(tooltipItem, chart) {
          var datasetLabel = chart.datasets[tooltipItem.datasetIndex].label || '';
          return datasetLabel + ': ' + number_format(tooltipItem.yLabel) + ' ft³';
        }
      }
    }
  }
});

//for cubic meter end



        $(document).on('change','#yearsummary', function() {

            getChart();
            var yearsummary = $('#yearsummary').val();
          
        });

        $(document).on('change','#meter_id', function() {

        getChart();
        var meter_id = $('#meter_id').val();

        });
        getChart();
function getChart() {
              var meter_id = $('#meter_id').val();
              var yearsummary = $('#yearsummary').val();
              if (meter_id != '' || yearsummary != '') {
                
              
                $.ajax({
                url: '<?= base_url() ?>consumer/monthly_payment/'+meter_id+'/'+yearsummary+'',
                method: 'GET',
                success: function(response) {
                 
                    
                    var resp = $.parseJSON(response);
                    months = [];
                    data = [];
                    //alert(response);
                    //for monthly start
                    $.each(resp.monthly, function(key, val) {
                        months.push(val.month_name);
                        data.push(val.totalsoldproduct);
                    })


                    monthlyChart.data.labels = months;
                    monthlyChart.data.datasets.forEach((dataset) => {
                        dataset.data = data;
                    });
                    monthlyChart.update();
                    //for monthly end

                    //for cubic
                    months_cubic = [];
                    data_monthly_cubic = [];
                    $.each(resp.total_cubic, function(key, val) {
                        months_cubic.push(val.month_name);
                        data_monthly_cubic.push(val.total_cubic);
                    })


                    myLineChart_cubic.data.labels = months_cubic;
                    myLineChart_cubic.data.datasets.forEach((dataset) => {
                        dataset.data = data_monthly_cubic;
                    });
                    myLineChart_cubic.update();
                    //for cubic


                    if (resp.yearly != 0) {
                      $('#show_annually_earnings').html('TOTAL AMOUNT OF '+yearsummary+': <span class="badge badge-pill badge-success">₱'+numberWithCommas(resp.yearly)+'</span>');
                    }else{
                      $('#show_annually_earnings').html('TOTAL AMOUNT OF '+yearsummary+': <span class="badge badge-pill badge-danger">₱'+numberWithCommas(resp.yearly)+'</span>');
                    }

                }

            });

          }

            
}


 });
    // // dont erase
    //for good avg
    // Swal.fire({
    //   title: 'Your cubic average for this month is good',
    //   text: 'Alert close in 5 secs',
    //   icon: 'info',
    //   showConfirmButton: false,
    //   allowOutsideClick: false,
    //   timer: 10000 
    // }).then((result) => {
    //     if (result.dismiss === Swal.DismissReason.timer) {
    //       Swal.fire({
    //         title: 'Your payment for this month is ₱10000',
    //         icon: 'info',
    //         showConfirmButton: true,
    //         allowOutsideClick: false
    //         // timer: 5000 
    //       })
    //     }
    // });


    // // this for bad ave
<?php 
if ($result == true) {
?>
    Swal.fire({
      title: 'Your Meter No. <?= $output ?> for this month is bad. Please contact Adminstrator',
      text: 'I will close in 5 secs',
      icon: 'warning',
      showConfirmButton: false,
      allowOutsideClick: false,
      timer: 4000
      //timer: 10000 
    }).then((result) => {
        if (result.dismiss === Swal.DismissReason.timer) {
          Swal.fire({
            // title: 'Your payment for this month is ₱10000',
            html: '<h2>Your payment for this month <strong style = "color:red"><?= $price ?></strong></h2>',
            icon: 'warning',
            showConfirmButton: true,
            allowOutsideClick: false
          })
        }
    });
<?php
}

?>

  </script>

</body>

</html>