
	<div class="limiter">
		<div class="container-login100" style="background-image: url('https://media.istockphoto.com/id/1200085423/photo/water.jpg?s=612x612&w=0&k=20&c=sGZ5wMBgFw3A2w4Kmo0B4-kKSwWUO2iASBmB640lB9U=');">
			<div class="wrap-login100 p-t-30 p-b-50">
				<span class="login100-form-title p-b-41">
                    <img src="<?= base_url().$System['system_logo'] ?>" alt="" width = "100"  class="rounded-circle" >
                    <h4 class="h4 text-gray-900"><?= $Page_name ?></h4>
				</span>
                
				<form id="submit_login" class="login100-form validate-form p-b-33 p-t-5">

					<div class="wrap-input100 validate-input" data-validate = "Enter username">
						<input id = "username-field" class="input100" type="text" name="username" placeholder="Username">
						<span class="focus-input100" data-placeholder="&#xe82a;"></span>
					</div>

					<div class="wrap-input100 validate-input" data-validate="Enter password">
						<input id = "password-field" class="input100" type="password" name="pass" placeholder="Password">
						<span class="focus-input100" data-placeholder="&#xe80f;"></span>
                        <span class="float-right fas fa-eye" id = "togglePassword" style = "margin-top:-35px; margin-right:20px;"></span>

					</div>

					<div class="container-login100-form-btn m-t-32">
                        <button type = "submit" name = "login_now" class="login100-form-btn">
							Login
						</button>
					</div>


				</form>


			</div>
		</div>
	</div>
	

	<div id="dropDownSelect1"></div>
<script>
    const togglePassword = document.querySelector('#togglePassword');
    const password = document.querySelector('#password-field');

    togglePassword.addEventListener('click', function (e) {
    // toggle the type attribute
    const type = password.getAttribute('type') === 'password' ? 'text' : 'password';
    password.setAttribute('type', type);
    // toggle the eye slash icon
    this.classList.toggle('fa-eye-slash');
    });


    $('#submit_login').on('submit',function(){

        var username = $('#username-field').val();
        var password = $('#password-field').val();

        if (username == '' || password == '') {
            return false;
        } 
        else {

            $.ajax({
                    url:"<?php echo base_url(); ?>login_register/login_form/",
                    method:"POST",
                    dataType:"JSON",
                    data:{login_consumer:'1', username:username, password:password},

                    beforeSend: function(){
                        
                        $('.login100-form-btn').prop('disabled', true);
                        $('#username-field').prop('disabled', true);
                        $('#password-field').prop('disabled', true);
                    },

                    success:function(data)
                    {
                        

                        $('.login100-form-btn').prop('disabled', false);
                        $('#username-field').prop('disabled', false);
                        $('#password-field').prop('disabled', false);

                        if (data.msg == 303) {

                            window.location.href = '<?= base_url() ?>';

                        }else{


                            Swal.fire({
                            icon: 'error',
                            title: 'Wrong Username/Password!',
                            text:  'Please try again'
                            });

                        }

                    
                    }
                            
                    });

        }


        return false;
    });
</script>