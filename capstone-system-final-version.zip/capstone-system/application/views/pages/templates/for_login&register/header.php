<!DOCTYPE html>
<html lang="en">
<head>
	<title><?= $System['system_name'] ?> - <?= $Page_name ?></title>
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width, initial-scale=1">
<!--===============================================================================================-->	
	<link href="<?= base_url().$System['system_logo'] ?>" rel="icon">
<!--===============================================================================================-->
	<link href="<?= base_url() ?>vendor/bootstrap/css/bootstrap.css" rel="stylesheet" type="text/css">
	<link href="<?= base_url() ?>vendor/fontawesome-free/css/all.css" rel="stylesheet" type="text/css">
    <link rel="stylesheet" type="text/css" href="<?= base_url() ?>font/font-awesome-4.7.0/css/font-awesome.min.css">
<!--===============================================================================================-->
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>font/Linearicons-Free-v1.0.0/icon-font.min.css">
<!--===============================================================================================-->

	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/util.css">
	<link rel="stylesheet" type="text/css" href="<?= base_url() ?>css/main-login.css">
<!--===============================================================================================-->
	<script src="https://cdn.jsdelivr.net/npm/sweetalert2@11"></script>
    <script src="<?= base_url() ?>vendor/jquery/jquery.js"></script>
</head>
<body>