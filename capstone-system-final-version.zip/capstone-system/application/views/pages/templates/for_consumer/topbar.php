
    
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content" class = "bg-gray-200">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top" style = "background-color: #ff6699 !important;">
          <button id="sidebarToggleTop" class="btn btn-pink rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow d-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="Search..."
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #FAA5C2;">
                    <div class="input-group-append">
                      <button class="btn btn-pink" type="button">
                        <i class="fas fa-search fa-sm" style = "color:#ffff"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            <?php 
                                $this->db->select('
                                table_a.*, 
                                table_b.*, 
                                table_c.*
                                ');
                                $this->db->from('tb_bill as table_a');
                                $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
                                $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');
                                $this->db->where('table_a.payment_status', 0);
                                $this->db->where('table_a.con_id', $this->session->con_id);
                                $this->db->order_by("table_a.bill_id", "desc");
                                $query = $this->db->get();
            ?>
              <style>
              div.scroll_notif {
                width: 100%;
                height: 200px;
                overflow: auto;
              }

            </style>
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <span class="badge badge-danger badge-counter total_disc"></span>
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header text-center" style = "background-color: #ff6699 !important; border-color: #ff6699;">
                  NOTIFICATION OF DISCONNECTION
                </h6>
                              <!-- here -->
                              <div class="scroll_notif">
                  <!-- loop here -->
                <?php 
                $count_disc = 1;
                $total = 0;
                                if ($query->num_rows() > 0) {
                                 
                                foreach ($query->result() as $key => $r) {
                                  $date_issued=date_create($r->date_issued);

                                  $date = date_create($r->date_issued);
                                  $day = date_format($date,"Y-m-d");
              
                                  // add 7 days to the date above
                                  $NewDate = date('Y-m-d', strtotime($day . "+14 days"));
              
                                  if (strtotime($NewDate) <= strtotime("now")) {
                                       
                                    $total += 1; 
                ?>

                <a class="dropdown-item d-flex align-items-center" href="<?= base_url().'Consumer-'.$r->con_id.'/'.trim($r->account_id, "#") ?>">
                  <div class="mr-3">
                    <div class="icon-circle bg-danger">
                      <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">Date issued on <?= date_format($date_issued,"M. d Y") ?></div>
                    <p class="font-weight-bold">
                      <?= $r->con_fname.' '.$r->con_lname ?>
                      <br>
                      Meter No. <span class="badge badge-secondary"><?= $r->meter_num ?></span>
                      <br>
                      <span class="font-weight-normal">
                      <!-- Notice: We've noticed unusually high spending for your account. -->
                      Due for Disconnection
                      </span>
                    </p>
                  </div>
                </a>
                                  <?php 
                                  //$count_disc++;
                                     
                                  }

                                }

                              }
                                  ?>
                  <!-- loop here -->
                </div>
               <script>
                $('.total_disc').html(<?= $total ?>);
               </script>
                <!-- here -->
                <a class="dropdown-item text-center small text-gray-500 d-none" href="#">Show All Alerts</a>
              </div>
            </li>
            <li class="nav-item dropdown no-arrow mx-1 d-none">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <span class="badge badge-warning badge-counter">2</span>
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header" style = "background-color: #ff6699 !important; border-color: #ff6699;">
                  Message Center
                </h6>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="img/man.png" style="max-width: 60px" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been
                      having.</div>
                    <div class="small text-gray-500">Administrator · 58m</div>
                  </div>
                </a>
               
                <a class="dropdown-item text-center small text-gray-500" href="#">Contact admin</a>
              </div>
            </li>
         
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <?php 
                
                if ($consumer_data['con_avatar'] == 'Boy') {
                  $con_ava = 'img/boy.png';
                } 
                elseif($consumer_data['con_avatar'] == 'Girl') {
                  $con_ava = 'img/girl.png';
                }
                elseif($consumer_data['con_avatar'] == 'Man') {
                  $con_ava = 'img/man.png';
                }
                else{
                  $con_ava = $consumer_data['con_avatar'];
                }
                ?>
                <img class="img-profile rounded-circle" src="<?= base_url().$con_ava ?>" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?= $consumer_data['con_fname'] ?> <?= $consumer_data['con_lname'] ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item" href="<?= base_url() ?>Home/MyProfile">
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>

                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar end-->