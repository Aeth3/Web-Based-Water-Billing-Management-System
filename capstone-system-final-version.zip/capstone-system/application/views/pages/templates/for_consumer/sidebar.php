

    <!-- Sidebar -->
    <ul class="navbar-nav sidebar sidebar-light accordion" id="accordionSidebar">
      <a class="sidebar-brand d-flex align-items-center justify-content-center" style = "background-color: #E16389 !important" href="index.html">
        <div class="sidebar-brand-icon">
          <?php 
          
          if ($consumer_data['con_avatar'] == 'Boy') {
            $con_ava = 'img/boy.png';
          } 
          elseif($consumer_data['con_avatar'] == 'Girl') {
            $con_ava = 'img/girl.png';
          }
          elseif($consumer_data['con_avatar'] == 'Man') {
            $con_ava = 'img/man.png';
          }
          else{
            $con_ava = $consumer_data['con_avatar'];
          }
          if ($Page_name == 'Dashboard') {
            $nav1 = 'active';
            $nav2 = '';
            $nav3 = '';
          } 
          elseif($Page_name == 'Dues') {
            $nav1 = '';
            $nav2 = 'active';
            $nav3 = '';
          }
          elseif($Page_name == 'Transaction') {
            $nav1 = '';
            $nav2 = '';
            $nav3 = 'active';
          }
          elseif($Page_name == 'MyProfile') {
            $nav1 = '';
            $nav2 = '';
            $nav3 = '';
            $nav4 = 'active';
          }
    
          ?>
          <img class="img-profile rounded-circle" src="<?= base_url().$con_ava ?>">
        </div>
        <div class="sidebar-brand-text mx-3"><?= $consumer_data['con_fname'] ?> <?= $consumer_data['con_lname'] ?></div>
      </a>
      <hr class="sidebar-divider my-0">
      <li class="nav-item <?= $nav1 ?>">
        <a class="nav-link" href="<?= base_url() ?>Home/Dashboard">
          <i class="fas fa-fw fa-tachometer-alt"></i>
          <span>Dashboard</span></a>
      </li>
      <hr class="sidebar-divider">
    
      <li class="nav-item d-none">
        <a class="nav-link collapsed" href="#" data-toggle="collapse" data-target="#collapseBootstrap"
          aria-expanded="true" aria-controls="collapseBootstrap">
          <i class="fas fa-list-alt"></i>
          <span>Pages</span>
        </a>
        <div id="collapseBootstrap" class="collapse" aria-labelledby="headingBootstrap" data-parent="#accordionSidebar">
          <div class="bg-white py-2 collapse-inner rounded">
            <h6 class="collapse-header">List of pages</h6>
            <a class="collapse-item" href="<?= base_url() ?>Home/Dues"><i class="fas fa-money-bill-alt"></i> Dues</a>
            <a class="collapse-item" href="<?= base_url() ?>Home/Transaction"><i class="fas fa-hand-holding-usd"></i> Transaction</a>
          </div>
        </div>
      </li>
      <li class="nav-item <?= $nav2 ?>">
        <a class="nav-link" href="<?= base_url() ?>Home/Dues">
          <i class="fas fa-money-bill-alt"></i>
          <span>Dues</span>
        </a>
      </li>
      <li class="nav-item <?= $nav3 ?>">
        <a class="nav-link" href="<?= base_url() ?>Home/Transaction">
          <i class="fas fa-hand-holding-usd"></i>
          <span>Transaction</span>
        </a>
      </li>
      <!-- <hr class="sidebar-divider"> -->
     
     
    
      
    </ul>
    <!-- Sidebar end-->