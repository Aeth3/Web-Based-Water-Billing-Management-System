
    
    <div id="content-wrapper" class="d-flex flex-column">
      <div id="content" class = "bg-gray-200">
        <!-- TopBar -->
        <nav class="navbar navbar-expand navbar-light bg-navbar topbar mb-4 static-top" style = "background-color: #ff6699 !important;">
          <button id="sidebarToggleTop" class="btn btn-pink rounded-circle mr-3">
            <i class="fa fa-bars"></i>
          </button>
          <ul class="navbar-nav ml-auto">
            <li class="nav-item dropdown no-arrow d-none">
              <a class="nav-link dropdown-toggle" href="#" id="searchDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-search fa-fw"></i>
              </a>
              <div class="dropdown-menu dropdown-menu-right p-3 shadow animated--grow-in"
                aria-labelledby="searchDropdown">
                <form class="navbar-search">
                  <div class="input-group">
                    <input type="text" class="form-control bg-light border-1 small" placeholder="Search..."
                      aria-label="Search" aria-describedby="basic-addon2" style="border-color: #FAA5C2;">
                    <div class="input-group-append">
                      <button class="btn btn-pink" type="button">
                        <i class="fas fa-search fa-sm" style = "color:#ffff"></i>
                      </button>
                    </div>
                  </div>
                </form>
              </div>
            </li>
            <style>
              div.scroll_notif {
                width: 100%;
                height: 200px;
                overflow: auto;
              }

            </style>
            <?php 
                                $this->db->select('
                                table_a.*, 
                                table_b.*, 
                                table_c.*
                                ');
                                $this->db->from('tb_bill as table_a');
                                $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
                                $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');
                                $this->db->where('table_a.payment_status', 0);
                                $this->db->order_by("table_a.bill_id", "desc");
                                $query = $this->db->get();
            ?>
            <li class="nav-item dropdown no-arrow mx-1">
              <a class="nav-link dropdown-toggle" href="#" id="alertsDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-bell fa-fw"></i>
                <span class="badge badge-secondary badge-counter total_disc">3+</span>
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="alertsDropdown">
                <h6 class="dropdown-header" style = "background-color: #ff6699 !important; border-color: #ff6699;">
                  Notification of Disconnection
                </h6>

                <!-- here -->
                <div class="scroll_notif">
                  <!-- loop here -->
                <?php 
                $count_disc = 1;
                $total = 0;
                                if ($query->num_rows() > 0) {
                                 
                                foreach ($query->result() as $key => $r) {
                                  $date_issued=date_create($r->date_issued);

                                  $date = date_create($r->date_issued);
                                  $day = date_format($date,"Y-m-d");
              
                                  // add 7 days to the date above
                                  //$NewDate = date('Y-m-d', strtotime($day . "+14 days"));
                                  $NewDate = date('Y-m-d', strtotime($day . "+14 days"));

                                  if (strtotime($NewDate) <= strtotime("now")) {
                                       
                                    $total += 1; 
                ?>

                <a class="dropdown-item d-flex align-items-center" onclick="printNotice('<?= base_url() ?>Print-Notice-<?= $r->bill_id ?>')" href="#printNotice">
                  <div class="mr-3">
                    <div class="icon-circle bg-danger">
                      <i class="fas fa-exclamation-triangle text-white"></i>
                    </div>
                  </div>
                  <div>
                    <div class="small text-gray-500">Date issued on <?= date_format($date_issued,"M. d, Y") ?></div>
                    <p class="font-weight-bold">
                      <?= $r->con_fname.' '.$r->con_lname ?>
                      <br>
                      Meter No. <span class="badge badge-secondary"><?= $r->meter_num ?></span>
                      <br>
                      <span class="font-weight-normal">
                      <!-- Notice: We've noticed unusually high spending for your account. -->
                      Due for Disconnection
                      </span>
                    </p>
                  </div>
                </a>
                                  <?php 
                                  //$count_disc++;
                                     
                                  }

                                }

                              }
                                  ?>
                  <!-- loop here -->
                </div>
               <script>
                $('.total_disc').html(<?= $total ?>);
               </script>
                <!-- here -->
                <a class="dropdown-item text-center small text-gray-500 d-none" href="#">Show All</a>
              </div>
            </li>
            <li class="nav-item dropdown no-arrow mx-1 d-none">
              <a class="nav-link dropdown-toggle" href="#" id="messagesDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <i class="fas fa-envelope fa-fw"></i>
                <span class="badge badge-warning badge-counter">2</span>
              </a>
              <div class="dropdown-list dropdown-menu dropdown-menu-right shadow animated--grow-in"
                aria-labelledby="messagesDropdown">
                <h6 class="dropdown-header" style = "background-color: #ff6699 !important; border-color: #ff6699;">
                  Message Center
                </h6>
                <!-- here -->
                <div class="scroll_notif">

                  <!-- loop here -->
                  
                  <?php 
                  //echo timeAgo('2023-01-01 18:26:00');

                  function timeAgo($timestamp){
                    $datetime1=new DateTime("now");
                    $datetime2=date_create($timestamp);
                    $diff=date_diff($datetime1, $datetime2);
                    $timemsg='';
                    if($diff->y > 0){
                        $timemsg = $diff->y .' year'. ($diff->y > 1?"'s":'');
                
                    }
                    else if($diff->m > 0){
                     $timemsg = $diff->m . ' month'. ($diff->m > 1?"'s":'');
                    }
                    else if($diff->d > 0){
                     $timemsg = $diff->d .' day'. ($diff->d > 1?"'s":'');
                    }
                    else if($diff->h > 0){
                     $timemsg = $diff->h .' hour'.($diff->h > 1 ? "'s":'');
                    }
                    else if($diff->i > 0){
                     $timemsg = $diff->i .' minute'. ($diff->i > 1?"'s":'');
                    }
                    else if($diff->s > 0){
                     $timemsg = $diff->s .' second'. ($diff->s > 1?"'s":'');
                    }
                
                $timemsg = $timemsg.' ago';
                return $timemsg;
                }
                  ?>
                <a class="dropdown-item d-flex align-items-center" href="#">
                  <div class="dropdown-list-image mr-3">
                    <img class="rounded-circle" src="img/man.png" style="max-width: 60px" alt="">
                    <div class="status-indicator bg-success"></div>
                  </div>
                  <div class="font-weight-bold">
                    <div class="text-truncate">Hi there! I am wondering if you can help me with a problem I've been
                      having.</div>
                    <div class="small text-gray-500">Administrator · 58m</div>
                  </div>
                </a>

                  <!-- loop here -->
                </div>
                <!-- here -->

                <a class="dropdown-item text-center small text-gray-500" href="#">All Messages</a>
              </div>
            </li>
         
            <div class="topbar-divider d-none d-sm-block"></div>
            <li class="nav-item dropdown no-arrow">
              <a class="nav-link dropdown-toggle" href="#" id="userDropdown" role="button" data-toggle="dropdown"
                aria-haspopup="true" aria-expanded="false">
                <img class="img-profile rounded-circle" src="<?= base_url().$this->session->admin_profile ?>" style="max-width: 60px">
                <span class="ml-2 d-none d-lg-inline text-white small"><?= $this->session->admin_name ?></span>
              </a>
              <div class="dropdown-menu dropdown-menu-right shadow animated--grow-in" aria-labelledby="userDropdown">
                <a class="dropdown-item d-none" href="#" >
                  <i class="fas fa-user fa-sm fa-fw mr-2 text-gray-400"></i>
                  Profile
                </a>
                <a class="dropdown-item" href="#" data-toggle="modal" data-target="#exampleModal">
                  <i class="fas fa-cogs fa-sm fa-fw mr-2 text-gray-400"></i>
                  Settings
                </a>
                <a class="dropdown-item d-none" href="#">
                  <i class="fas fa-list fa-sm fa-fw mr-2 text-gray-400"></i>
                  Activity Log
                </a>
                <div class="dropdown-divider"></div>
                <a class="dropdown-item" href="javascript:void(0);" data-toggle="modal" data-target="#logoutModal">
                  <i class="fas fa-sign-out-alt fa-sm fa-fw mr-2 text-gray-400"></i>
                  Logout
                </a>
              </div>
            </li>
          </ul>
        </nav>
        <!-- Topbar end-->

        <!-- Modal -->
<div class="modal fade" id="exampleModal" tabindex="-1" aria-labelledby="exampleModalLabel" aria-hidden="true">
  <div class="modal-dialog">
    <div class="modal-content">
      <div class="modal-header">
        <h5 class="modal-title" id="exampleModalLabel">Credentials</h5>
        <button type="button" class="btn close" data-dismiss="modal" aria-label="Close">
          <span aria-hidden="true">&times;</span>
        </button>
      </div>
      <div class="modal-body">
                      <?php 

                                      $this->db->select('*');
                                      $this->db->from('admin_credentials');
                                      $this->db->where('admin_id',1);
                                      $result = $this->db->get();
                                      $row = $result->row_array();
                                    
                      ?>
        <form id="credentials_admin" class="g-3 needs-validation-admin-credentials" novalidate>

          <div class="form-group">
            <label for="formGroupExampleInput">Username</label>
            <input type="text" class="form-control" id="admin_uname" value = "<?= $row['admin_uname'] ?>" placeholder="Username" required>
          </div>
          <div class="form-group">
            <label for="formGroupExampleInput2">Old Password</label>
            <input type="text" class="form-control" id="Old_Password" required>
          </div>
          <div class="form-group">
            <label for="formGroupExampleInput3">New Password</label>
            <input type="text" class="form-control" id="New_Password" required>
          </div>
       
      </div>
      <div class="modal-footer">
        <button type="button" class="btn btn-secondary" data-dismiss="modal">Close</button>
        <button type="submit" id="change_admin" class="btn btn-capstone">Change Now</button>
      </div>
      </form>
    </div>
  </div>
</div>
<style>
  .wrong-password{
    border-color: #fc544b;
    padding-right: calc(1.5em + 0.75rem);
    background-image: url(<?= base_url() ?>img/wrong.svg);
    background-repeat: no-repeat;
    background-position: center right calc(0.375em + 0.1875rem);
    background-size: calc(0.75em + 0.375rem) calc(0.75em + 0.375rem);
  }
</style>
<script>
 
 function printNotice(url) {
    newwindow=window.open(url,'name','width=1500,height=1000');
    if (window.focus) {newwindow.focus()}
    return false;
  }

  //need validation start
  (function () {
        'use strict'

        var forms = document.querySelectorAll('.needs-validation-admin-credentials')

        Array.prototype.slice.call(forms)
            .forEach(function (form) {
            form.addEventListener('submit', function (event) {
                if (!form.checkValidity()) {
                event.preventDefault()
                event.stopPropagation()
                }

                var admin_uname = $('#admin_uname').val();
                var Old_Password = $('#Old_Password').val();
                 var New_Password = $('#New_Password').val();

                if (admin_uname == "" || Old_Password == "" || New_Password == "") {
                   
                 
                    form.classList.add('was-validated')

                }else{
                
                    
                  $.ajax({
                    url:"<?php echo base_url(); ?>admin/admin_cre/",
                    method:"POST",
                    dataType:"JSON",
                    data:{admin_cre:'1', admin_uname:admin_uname, Old_Password:Old_Password , New_Password:New_Password},

                    beforeSend: function(){
                        
                        $('#admin_uname').prop('disabled', true);
                        $('#Old_Password').prop('disabled', true);
                        $('#New_Password').prop('disabled', true);
                        $('#change_admin').prop('disabled', true);
        
                    },

                    success:function(data)
                    {
                        
                        $('#admin_uname').prop('disabled', false);
                        $('#Old_Password').prop('disabled', false);
                        $('#New_Password').prop('disabled', false);
                        $('#change_admin').prop('disabled', false);

                  
                        if (data.msg == 303) {

                            Swal.fire({
                            icon: 'success',
                            title: 'SAVED',
                            text: 'Credentials Updated Successfully',
                            showConfirmButton: true,
                            allowOutsideClick: false
                            });
                          $('.needs-validation-admin-credentials').trigger("reset").removeClass('was-validated');


                        }else{


                            Swal.fire({
                            icon: 'error',
                            title: 'Old Password is Invalid',
                            showConfirmButton: true,
                            allowOutsideClick: false
                            });
                            $('.needs-validation-admin-credentials').trigger("reset");

                        }

                    
                    }
                            
                    });

                }
                

                event.preventDefault();
                event.stopPropagation();


            }, false)
            });
        })()
</script>