  <!-- Login Content -->
  <script src="<?= base_url() ?>vendor/bootstrap/js/bootstrap.bundle.js"></script>
  <script src="<?= base_url() ?>vendor/jquery-easing/jquery.easing.js"></script>

  <!-- Select2 -->
  <script src="<?= base_url() ?>vendor/select2/dist/js/select2.min.js"></script>
  <!-- Bootstrap Datepicker -->
  <script src="<?= base_url() ?>vendor/bootstrap-datepicker/js/bootstrap-datepicker.min.js"></script>
  <!-- Bootstrap Touchspin -->
  <script src="<?= base_url() ?>vendor/bootstrap-touchspin/js/jquery.bootstrap-touchspin.js"></script>
  <!-- ClockPicker -->
  <script src="<?= base_url() ?>vendor/clock-picker/clockpicker.js"></script>

  <script src="<?= base_url() ?>js/main.js"></script>
</body>

</html>