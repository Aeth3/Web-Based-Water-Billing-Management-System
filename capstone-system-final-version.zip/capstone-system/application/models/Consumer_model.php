<?php 

class Consumer_model extends CI_Model
{


        public function __construct(){

            $this->load->database();

            //$this->table = 'product'; 
            date_default_timezone_set('Asia/Manila');

        }

          
            function login_consumer(){  //login_consumer 

                $this->db->where('cre_username', $this->input->post('username', true));
                $this->db->where('cre_password', md5($this->input->post('password', true)));
                $result = $this->db->get('tb_credentials');
            
            
                if($result->num_rows() == 1){
            
                    return $result->row_array();
            
                }else{
            
                    return false;
            
                }
            
            } //login_consumer
          
            function consumer_info($con_id){ //consumer_info

                $this->db->select('*');
                $this->db->from('tb_consumers as table_a');
                $this->db->join('tb_credentials as table_b', 'table_a.con_id = table_b.con_id', 'inner');                
                $this->db->where('table_a.con_id', $con_id);
                $query = $this->db->get();
                return $query->row_array();

            } //consumer_info
            function consumer_info_fetch($con_id){ //consumer_info

                $this->db->select('*');
                $this->db->from('tb_consumers as table_a');
                $this->db->join('tb_credentials as table_b', 'table_a.con_id = table_b.con_id', 'inner'); 
                $this->db->join('tb_prk as table_c', 'table_a.prk_id = table_c.prk_id', 'inner');                
               
                $this->db->where('table_a.con_id', $con_id);
                $query = $this->db->get();
                return $query->result_array();

            } //consumer_info

            function consumer_dues($con_id,$condition){

                $this->db->select('
                table_a.*, 
                table_b.*, 
                table_c.*
                ');
                $this->db->from('tb_bill as table_a');
                $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
                $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');
                $this->db->where('table_b.con_id', $con_id);
                $this->db->where('table_a.payment_status', $condition);
                $this->db->order_by("table_a.bill_id", "desc");
                $query = $this->db->get();

                return array(
                    'fetch'     => $query->result(), 
                    'num_rows'  => $query->num_rows()
                );
                
            }
            function consumer_monthly_payment($meter_id,$year){

                $consumer = "SELECT 
                    mt.month_name,
                    IFNULL((select SUM(total_amount)
                                from tb_bill
                                where MONTHNAME(monthly_bill) = mt.month_name
                                and YEAR(monthly_bill) = ".$year." and payment_status = 1 and meter_id  = ".$meter_id ."
                            ), 0 ) as totalsoldproduct
                            ,
        
                    (select SUM(total_amount) 
                        from tb_bill
                        where YEAR(monthly_bill) = ".$year."
                    ) as totalsoldproduct_all
        
                from months_table as mt;";

             $data = $this->db->query($consumer);

            $ar = [];
                if ($data->num_rows() > 0) {
                    
                    foreach ($data->result_array() as $row) {
                        $ar[] = $row;
                    }
                    
                }

                $this->db->select('sum(total_amount) as total_amount');
                $this->db->from('tb_bill');
                $this->db->where('YEAR(monthly_bill)',$year);
                $this->db->where('payment_status',1);
                $this->db->where('meter_id',$meter_id);
                $result = $this->db->get();
                $total_amount = $result->row_array();

                if ($data->num_rows() > 0) {
                    
                    if ($total_amount['total_amount'] != 0) {
                        $total_amount = $total_amount['total_amount'];
                    }else{
                        $total_amount = 0;
                    }

                }else{
                    $total_amount = 0;
                }
               

                //for cubic
                $cubic = "SELECT 
                mt.month_name,
                IFNULL((select current_reading - previous_reading
                            from tb_bill
                            where MONTHNAME(monthly_bill) = mt.month_name
                            and YEAR(monthly_bill) = ".$year." and payment_status = 1 and meter_id  = ".$meter_id ."
                        ), 0 ) as total_cubic
            from months_table as mt;";

                $data_cubic = $this->db->query($cubic);
                $cubic_ar = [];
                if ($data_cubic->num_rows() > 0) {
                    
                    foreach ($data_cubic->result_array() as $row) {
                        $cubic_ar[] = $row;
                    }
                    
                }
                //for cubic end


                $output = array(
                                    'manually'      => $ar , 
                                    'annually'      => $total_amount,
                                    'total_cubic'   => $cubic_ar
                                );

                //return $ar;
                return $output;

            }
            function update_creden_consumer($data){
                $this->db->where('con_id', $data['con_id']);
                $this->db->update('tb_credentials', $data);
                return true;
            }
//end of modal pages model
}