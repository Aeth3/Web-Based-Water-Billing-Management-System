<?php
defined('BASEPATH') OR exit('No direct script access allowed');
#[\AllowDynamicProperties]
class Admin extends CI_Controller {


    function __construct() { 

        parent::__construct(); 
        $this->load->library('session');

    } 

//pages 1 sidebar start ----------------------------------------------------------------------->

    //dashboard start 
	public function home_admin()
	{

      
        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

            $page = "home";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    
             $data = array(
                
                'System' => $this->Admin_model->system_title(),
                'Page_name' => 'Dashboard',
                'Admin_name' => 'Administrator'

            );
            $this->load->view('pages/templates/for_admin/header', $data);
            $this->load->view('pages/templates/for_admin/sidebar', $data);
            $this->load->view('pages/templates/for_admin/topbar', $data);
            $this->load->view('pages/admin/static_content/content_card', $data);
            $this->load->view('pages/admin/'.$page, $data);
            $this->load->view('pages/templates/for_admin/footer', $data);

        }else{

            show_404();

        }

	}
    //dashboard end

    // billing_admin
	public function billing_admin()
	{

        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

           
            $page = "billing";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    
             $data = array(
                
                'System' => $this->Admin_model->system_title(),
                'Page_name' => 'Billing',
                'Admin_name' => 'Administrator'

            );
            $this->load->view('pages/templates/for_admin/header', $data);
            $this->load->view('pages/templates/for_admin/sidebar', $data);
            $this->load->view('pages/templates/for_admin/topbar', $data);
            $this->load->view('pages/admin/static_content/content_card', $data);
            $this->load->view('pages/admin/'.$page, $data);
            $this->load->view('pages/templates/for_admin/footer', $data);

        }else{

            show_404();
            
        }

	}
    // billing_admin end
    
    // transaction_admin start
    public function transaction_admin()
	{

        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

           
            $page = "billing";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    
             $data = array(
                
                'System' => $this->Admin_model->system_title(),
                'Page_name' => 'Transaction',
                'Admin_name' => 'Administrator'

            );
            $this->load->view('pages/templates/for_admin/header', $data);
            $this->load->view('pages/templates/for_admin/sidebar', $data);
            $this->load->view('pages/templates/for_admin/topbar', $data);
            $this->load->view('pages/admin/static_content/content_card', $data);
            $this->load->view('pages/admin/'.$page, $data);
            $this->load->view('pages/templates/for_admin/footer', $data);

        }else{

            show_404();
            
        }

	}
    // transaction_admin end


//pages 1 sidebar end ----------------------------------------------------------------------->


//pages 2 sidebar start ----------------------------------------------------------------------->

    // all_purok start
	public function all_purok()
	{

        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

           
            $page = "all_purok";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    
             $data = array(
                
                'System' => $this->Admin_model->system_title(),
                'Page_name' => 'All Purok',
                'Admin_name' => 'Administrator'

            );
            $this->load->view('pages/templates/for_admin/header', $data);
            $this->load->view('pages/templates/for_admin/sidebar', $data);
            $this->load->view('pages/templates/for_admin/topbar', $data);
            $this->load->view('pages/admin/static_content/content_card', $data);
            $this->load->view('pages/admin/'.$page, $data);
            $this->load->view('pages/templates/for_admin/footer', $data);

        }else{

            show_404();
            
        }

	}
    // all_purok end

    // all_meter_number start
    public function all_meter_number()
	{
        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

           
            $page = "all_meter_num";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    
             $data = array(
                
                'System' => $this->Admin_model->system_title(),
                'Page_name' => 'All Meter Number',
                'Admin_name' => 'Administrator'

            );
            $this->load->view('pages/templates/for_admin/header', $data);
            $this->load->view('pages/templates/for_admin/sidebar', $data);
            $this->load->view('pages/templates/for_admin/topbar', $data);
            $this->load->view('pages/admin/static_content/content_card', $data);
            $this->load->view('pages/admin/'.$page, $data);
            $this->load->view('pages/templates/for_admin/footer', $data);

        }else{

            show_404();
            
        }
    }
    // all_meter_number end

    // all_consumer start
    public function all_consumer()
	{
        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

           
            $page = "all_consumer";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    
             $data = array(
                
                'System' => $this->Admin_model->system_title(),
                'Page_name' => 'All Consumer',
                'Admin_name' => 'Administrator',
                'All_purok'  => $this->Admin_model->fetch_purok(),
                'All_meter_num'  => $this->Admin_model->fetch_meter_num()


            );
            $this->load->view('pages/templates/for_admin/header', $data);
            $this->load->view('pages/templates/for_admin/sidebar', $data);
            $this->load->view('pages/templates/for_admin/topbar', $data);
            $this->load->view('pages/admin/static_content/content_card', $data);
            $this->load->view('pages/admin/'.$page, $data);
            $this->load->view('pages/templates/for_admin/footer', $data);

        }else{

            show_404();
            
        }
    }
    // all_consumer end
    // view_consumer start
    public function view_consumer($param=null)
	{
        if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

           
            $page = "view_consumer";


            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          

                show_404();

             }
    

            if ($param != null) {


                $con_id = $param;
                $account_id = '#'.$this->uri->segment(2);

                $data = array(
                
                    'System' => $this->Admin_model->system_title(),
                    'Page_name' => 'Consumer',
                    'Admin_name' => 'Administrator',
                    'All_purok'  => $this->Admin_model->fetch_purok(),
                    'All_meter_num'  => $this->Admin_model->fetch_meter_num(),
                    'Consumer_Info'  => $this->Admin_model->consumer_Individual($con_id,$account_id)
                   
                );

                $this->load->view('pages/templates/for_admin/header', $data);
                $this->load->view('pages/templates/for_admin/sidebar', $data);
                $this->load->view('pages/templates/for_admin/topbar', $data);
                $this->load->view('pages/admin/static_content/content_card', $data);
                $this->load->view('pages/admin/'.$page, $data);
                $this->load->view('pages/templates/for_admin/footer', $data);

            }else{

                show_404();

            }


        }else{

            show_404();
            
        }
    }
    // view consumer end
    public function getMeterNum(){  //get meter number

        // Search term
        $searchTerm = $this->input->post('searchTerm');
        $response = $this->Admin_model->getMeterNum($searchTerm);
  
        echo json_encode($response);
     } //get meter number

     public function print_invoice($param){

        if ($param != null) {
            
        $page = "print_invoice";
        if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
      

            show_404();

         }
         $data = array(
                
            'System'            => $this->Admin_model->system_title(),
            'Page_name'         => 'Consumer',
            'Admin_name'        => 'Administrator',
            'All_purok'         => $this->Admin_model->fetch_purok(),
            'All_meter_num'     => $this->Admin_model->fetch_meter_num(),
            'Param'             => $param
           
        );
        $this->load->view('pages/admin/'.$page, $data);

    }else{
        
        show_404();

    }

     }
     public function print_notice($param){
        if ($param != null) {
            
            $page = "print_notice";
            if (!file_exists(APPPATH.'views/pages/admin/'.$page.'.php')) {
          
    
                show_404();
    
             }
             $data = array(
                    
                'System'            => $this->Admin_model->system_title(),
                'Page_name'         => 'Consumer',
                'Admin_name'        => 'Administrator',
                'All_purok'         => $this->Admin_model->fetch_purok(),
                'All_meter_num'     => $this->Admin_model->fetch_meter_num(),
                'Param'             => $param
               
            );
            $this->load->view('pages/admin/'.$page, $data);
    
        }else{
            
            show_404();
    
        }
     }
//pages 2 sidebar end ----------------------------------------------------------------------->


//Form start ----------------------------------------------------------------------->

    //For purok start
	public function for_purok()
	{

    if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

      if (isset($_POST['ADD_PUROK'])) { //add purok start
        # code...
      
        $Purok_Name = $this->input->post('Purok_Name', true);
        $Purok_Sort = $this->input->post('Purok_Sort', true);
        
        $data = array(

                    'prk_name' => ucfirst($Purok_Name),
                    'prk_sort' => $Purok_Sort

                    );

         $response = $this->Admin_model->add_purok($data);

        if ($response) {
            $result = 303;
        }else{
            $result = 404;
        }



    
      
         $output = array(
             'msg'		=>	$result
         );
 
        
         echo json_encode($output);
          

    } //add purok end


    if (isset($_POST['all_prk'])) {  //fetch prk start
      


        $draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));
  
        $this->db->order_by("prk_sort", "asc");
        $query = $this->db->get("tb_prk");
                
        $data = [];
  
        $x = 1;
        foreach($query->result() as $r) {
             $data[] = array(
                        "Select"     => "",
                        "#"          => $x++,
                        "Purok_Name" => $r->prk_name,
                        "Purok_Sort" => $r->prk_sort,
                        "Action"     => ' <div class="btn-group dropleft">

                        <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown"
                          aria-haspopup="true" aria-expanded="false">
                          <i class="fas fa-eye"></i>
                        </button>

                        <div class="dropdown-menu text-left pl-2 pr-2 bg-gray-200">
                            
                        <div class = "bg-gray-100">
                        <a href="'.$r->prk_name.'" id = "'.$r->prk_id.'" class="dropdown-item btn-hover-details btn btn-lg p-1 viewPrkBtn">
                            <span class="icon">
                                <i class="fas fa-address-book"></i>
                            </span>
                            <span class="text">View List Of Purok</span>
                        </a>                        
                        <a href="'.$r->prk_name.'" id = "'.$r->prk_id.'" class="dropdown-item btn-hover-edit btn btn-lg p-1 editPrkBtn">
                            <span class="icon">
                                <i class="fas fa-edit text-left"></i>
                            </span>
                            <span class="text">Edit Purok</span>
                        </a>
                        <a href="'.$r->prk_name.'" id = "'.$r->prk_id.'" class="dropdown-item btn-hover-delete btn  btn-lg p-1 deletePrkBtn">
                            <span class="icon">
                                <i class="fas fa-trash"></i>
                            </span>
                            <span class="text">Delete Purok</span>
                        </a>
                        </div> 

                        </div>

                      </div>'
             );
        }
  
  
        $result = array(
                 "draw" => $draw,
                   "recordsTotal" => $query->num_rows(),
                   "recordsFiltered" => $query->num_rows(),
                   "data" => $data
              );
  
  
        echo json_encode($result);
        exit();
  

    }  //fetch prk end
 

    if (isset($_POST['all_prk_list'])) {   //all_prk_list start 
      


        $draw = intval($this->input->get("draw"));
        $start = intval($this->input->get("start"));
        $length = intval($this->input->get("length"));
        $prk_id = $this->input->post('prk_id',true);

        $this->db->select('
        table_a.*,
        table_b.*,
        table_c.*,
        GROUP_CONCAT(table_c.meter_num SEPARATOR ", ") as meter_number
        ');
        $this->db->from('tb_consumers as table_a');
        $this->db->join('tb_owner_meter as table_b', 'table_a.con_id = table_b.con_id','left');
        $this->db->join('tb_meter_num as table_c', 'table_b.meter_id = table_c.meter_id','left');
        $this->db->where('table_a.prk_id',$prk_id);
        $this->db->order_by("sorting_num", "asc");
        $this->db->group_by('table_a.con_id');
        $query = $this->db->get();

        $data = [];
  
        $x = 1;
        foreach($query->result() as $r) {
             $data[] = array(
                        "#"             => $x++,
                        "Consumer_name" => $r->con_fname.' '.$r->con_lname,
                        "Meter_number"  => $r->meter_number,
                        "Blank"         => '_________________________________',
                        "Sorting"       => '<span class="text-light" hidden>'.$r->sorting_num.'</span><input type="number" min ="1" id = "'.$r->con_id.'" value = "'.$r->sorting_num.'" class="form-control text-center get_value_sort" style ="cursor:pointer;">',
                        "Action"        => '<a href = "'.base_url().'Consumer-'.$r->con_id.'/'.trim($r->account_id, "#").'" data-toggle="tooltip" data-placement="bottom" title="View Full Details of '.$r->con_fname.' '.$r->con_lname.' " class="btn btn-outline-info"><i class="fas fa-eye"></i></a>
                        <input type="hidden"  value = "'.$r->prk_id.'" class="form-control text-center get_prk" style ="cursor:pointer;">
                        '
             );
        }
  
  
        $result = array(
                    "draw"              => $draw,
                    "recordsTotal"      => $query->num_rows(),
                    "recordsFiltered"   => $query->num_rows(),
                    "data"              => $data
              );
  
  
        echo json_encode($result);
        exit();
  

    }    //all_prk_list End 

    if (isset($_POST['sorting_user'])) { //sorting user start sorting_user

        //get_user_id
        //get_value_sort
        $get_user_id = $this->input->post('get_user_id',true);
        $get_value_sort = $this->input->post('get_value_sort',true);

        $response = $this->Admin_model->sort_status_user($get_user_id,$get_value_sort);
        if ($response == true) {

            $result = 303;

        }else{

            $result = 404;

        }
        $result = array(
                    "msg"    => $result
                 );


        echo json_encode($result);
        exit();
    } //sorting user end 

    if (isset($_POST['deletePrk'])) {  // deletePrk
      

        $prk_id = $this->input->post('prk_id',true);
    

         $response = $this->Admin_model->delete_purok($prk_id);

        if ($response) {
            $result = 303;
        }else{
            $result = 404;
        }


         $output = array(
             'msg'		=>	$result
         );
 
        
         echo json_encode($output);


    }// deletePrk end

    if (isset($_POST['getPrk'])) {  // getPrk
      

        $prk_id = $this->input->post('prk_id',true);
    

         $response = $this->Admin_model->get_purok($prk_id);

        if ($response) {
            $result = 303;
        }else{
            $result = 404;
        }

      
         $output = array(
             'msg'		=>	$result,
             'Prk_ID'		=>	$response['prk_id'],
             'prk_name'		=>	$response['prk_name'],
             'prk_sort'		=>	$response['prk_sort']

         );
 
        
         echo json_encode($output);


    }// getPrk end

    if (isset($_POST['check_Purokname'])) {  // check_Purokname
      

        $purok_name = $this->input->post('purok_name', true);
        $response = $this->Admin_model->check_purokname_exist($purok_name);

         print($response);


    }// check_Purokname end

    
    if (isset($_POST['UPDATE_PUROK'])) { //UPDATE_PUROK start
        # code...
        $prk_id = $this->input->post('Prk_ID', true);
        $Purok_Name = $this->input->post('Purok_Name', true);
        $Purok_Sort = $this->input->post('Purok_Sort', true);
        
        $set_data = array(
                    'prk_id' => $prk_id,
                    'prk_name' => ucfirst($Purok_Name),
                    'prk_sort' => $Purok_Sort
                    );

         $response = $this->Admin_model->update_purok($set_data);

        if ($response) {
            $result = 303;
        }else{
            $result = 404;
        }

      
         $output = array(
             'msg'		=>	$result
         );
 
        
         echo json_encode($output);
          

    } //UPDATE_PUROK end

    }else{

            show_404();
            
        }
	}//For purok end 

    public function for_meter_number(){ //For meter number Start

    if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

        if (isset($_POST['all_meter_num'])) {  //fetch meter number start
      


            $draw = intval($this->input->get("draw"));
            $start = intval($this->input->get("start"));
            $length = intval($this->input->get("length"));
      
            // $this->db->order_by("meter_id", "asc"); //orginal
            // $query = $this->db->get("tb_meter_num");


            $this->db->select('table_a.*, table_b.meter_id as meterb_id,table_b.con_id as conb_id');
            $this->db->from('tb_meter_num as table_a');
            $this->db->join('tb_owner_meter as table_b', 'table_a.meter_id = table_b.meter_id', 'left');
            $this->db->order_by("table_a.meter_id", "asc");
            $query = $this->db->get();
            
              
                    
            $data = [];
            $hello ='';
            $x = 1;
            foreach($query->result() as $key_1 => $r) {

                if ($r->meter_id == $r->meterb_id) {
                    $delete_button ='';
                }else{
                    $delete_button ='<a href="'.$r->meter_num.'" id = "'.$r->meter_id.'" class="dropdown-item btn-hover-delete btn  btn-lg p-1 deleteMeterBtn">
                    <span class="icon">
                        <i class="fas fa-trash"></i>
                    </span>
                    <span class="text">Delete Meter</span>
                </a>';
                }

                 $data[] = array(
                            "Select"       => "",
                            "#"            => $x++,
                            "Meter_Number" => $r->meter_num,
                            "Action"       => ' <div class="btn-group dropleft">
    
                            <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown"
                              aria-haspopup="true" aria-expanded="false">
                              <i class="fas fa-eye"></i>
                            </button>
    
                            <div class="dropdown-menu text-left pl-2 pr-2 bg-gray-200">
                                
                            <div class = "bg-gray-100">
                            <a href="'.$r->meter_num.'" id = "'.$r->meter_id.'" class="dropdown-item btn-hover-edit btn  btn-lg p-1 editMeterBtn">
                                <span class="icon">
                                    <i class="fas fa-edit text-left"></i>
                                </span>
                                <span class="text">Edit Meter</span>
                             
                            </a>
                            '.$delete_button.'
                            </div> 
    
                            </div>
    
                          </div>'
                 );
            }
      
      
            $result = array(
                     "draw" => $draw,
                       "recordsTotal" => $query->num_rows(),
                       "recordsFiltered" => $query->num_rows(),
                       "data" => $data
                  );
      
      
            echo json_encode($result);
            exit();
      
    
        }  //fetch meter number end
       

        if (isset($_POST['ADD_METER'])) { //add meter start
            # code...
          
            $Meter_Number = $this->input->post('Meter_Number', true);
            
            $data = array(
    
                        'meter_num' => $Meter_Number
    
                        );
    
             $response = $this->Admin_model->add_meter_number($data);
    
            if ($response) {
                $result = 303;
            }else{
                $result = 404;
            }
    
    
    
        
          
             $output = array(
                 'msg'		=>	$result
             );
     
            
             echo json_encode($output);
              
    
        } //add meter end

        if (isset($_POST['getMeter'])) {  // getMeter single start
      

            $meter_id = $this->input->post('meter_id',true);
        
    
             $response = $this->Admin_model->get_meter($meter_id);
    
            if ($response) {
                $result = 303;
            }else{
                $result = 404;
            }
    
          
             $output = array(
                 'msg'		        =>	$result,
                 'Meter_ID'		    =>	$response['meter_id'],
                 'Meter_Number'		=>	$response['meter_num']    
             );
     
            
             echo json_encode($output);
    
    
        }// getMeter single end

        if (isset($_POST['meter_number'])) {  // getMeter multiple start
      

            $meter_id = $this->input->post('meter_id',true);
            $meter_number = '';    
            $query ="SELECT * FROM tb_meter_num WHERE meter_id IN ($meter_id)";
            $data = $this->db->query($query);

        
            foreach ($data->result_array() as $key => $value) {

                $meter_number .= '<p class="text-muted mb-0">'.$value['meter_num'].'</p>';

                }
         

             $output = array(
                 'Meter_Number'		=>	$meter_number   
             );

            
             echo json_encode($output);
    
    
        }// getMeter multiple end

        if (isset($_POST['UPDATE_METER'])) { //UPDATE_METER start
            # code...
            $Meter_ID = $this->input->post('Meter_ID', true);
            $Meter_Number = $this->input->post('Meter_Number', true);
            
            $set_data = array(
                        'meter_id' => $Meter_ID,
                        'meter_num' => $Meter_Number
                        );
    
             $response = $this->Admin_model->update_meter($set_data);
    
            if ($response) {
                $result = 303;
            }else{
                $result = 404;
            }
    
          
             $output = array(
                 'msg'		=>	$result
             );
     
            
             echo json_encode($output);
              
    
        } //UPDATE_METER end

        if (isset($_POST['deleteMeter'])) {  // deleteMeter
      

            $meter_id = $this->input->post('meter_id',true);
        
    
             $response = $this->Admin_model->delete_meter($meter_id);
    
            if ($response) {
                $result = 303;
            }else{
                $result = 404;
            }
    
    
             $output = array(
                 'msg'		=>	$result
             );
     
            
             echo json_encode($output);
    
    
        }// deleteMeter end


            }else{

            show_404();
            
        }

    } //For meter number End

    public function for_consumer(){ //For consumer Start



    if ($this->session->admin_id || $this->session->admin_name || $this->session->admin_profile || $this->session->ad_access || $this->session->logged_admin) {

        if (isset($_POST['all_consumer'])) {  //fetch consumer start
      


            $draw = intval($this->input->get("draw"));
            $start = intval($this->input->get("start"));
            $length = intval($this->input->get("length"));
      
            //query
            // $this->db->order_by("prk_sort", "asc");
            // $query = $this->db->get("tb_prk");
            $this->db->select('table_a.*,table_b.*,table_c.*');
            $this->db->from('tb_consumers as table_a');
            $this->db->join('tb_prk as table_b', 'table_a.prk_id = table_b.prk_id', 'inner');
            $this->db->join('tb_credentials as table_c', 'table_a.con_id = table_c.con_id', 'inner');
            // $this->db->where('table_c.cre_status', 1);
            $this->db->order_by("table_c.cre_status", "desc");
            $this->db->order_by("table_a.con_id", "asc");
            $query = $this->db->get();
            //query
      
            $data = [];

            $x = 1;
            foreach($query->result() as $r) {

                if ($r->cre_status == 1) {
                    $status_con = '<span class="badge badge-pill badge-success">Active</span>';
                    $btn = '<a href="'.$r->con_fname.' '.$r->con_lname.'" id = "'.$r->con_id.'" class="dropdown-item btn-hover-delete btn btn-outline-capstone btn-lg p-1 inactiveConsumerBtn">
                    <span class="icon">
                        <i class="fas fa-user-times"></i>
                    </span>
                    <span class="text">Inactive</span>
                </a>';
                } else {
                    $status_con = '<span class="badge badge-pill badge-danger">Inactive</span>';
                    $btn = '<a href="'.$r->con_fname.' '.$r->con_lname.'" id = "'.$r->con_id.'" class="dropdown-item btn-hover-success btn btn-outline-capstone btn-lg p-1 activeConsumerBtn">
                    <span class="icon">
                     <i class="fas fa-user-check"></i>
                    </span>
                    <span class="text">Activate</span>
                </a>';
                }
                
                 $data[] = array(
                            "Select"     => "",
                            "#"          => $x++,
                            "Account_ID" => $r->account_id,
                            "Full_Name"  => $r->con_fname.' '.$r->con_lname,
                            "Purok_Name" => $r->prk_name,
                            "Status"     => $status_con,
                            "Action"     => '<div class="btn-group dropleft">
    
                            <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown"
                              aria-haspopup="true" aria-expanded="false">
                              <i class="fas fa-eye"></i>
                            </button>
    
                            <div class="dropdown-menu text-left pl-2 pr-2 bg-gray-200">
                                
                            <div class = "bg-gray-100">
                            <a href="'.base_url().'Consumer-'.$r->con_id.'/'.trim($r->account_id, "#").'" id = "'.$r->con_id.'" class="dropdown-item btn-hover-details btn btn-outline-capstone btn-lg p-1 editConsumerBtn">
                                <span class="icon">
                                    <i class="fas fa-info-circle text-left"></i>
                                </span>
                                <span class="text">View Details</span>
                            </a>
                            <a href="#NoFunctionForNow" id = "'.$r->con_id.'" class="dropdown-item btn-hover-edit btn btn-outline-capstone btn-lg p-1 editConsumerBtn d-none">
                                <span class="icon">
                                    <i class="fas fa-edit text-left"></i>
                                </span>
                                <span class="text">Edit Consumer</span>
                            </a>
                            '.$btn.'
                            </div> 
    
                            </div>
    
                          </div>'
                 );
            }
      
      
            $result = array(
                       "draw" => $draw,
                       "recordsTotal" => $query->num_rows(),
                       "recordsFiltered" => $query->num_rows(),
                       "data" => $data
                  );
      
      
            echo json_encode($result);
            exit();
      
    
        }  //fetch consumer end
        
        if(isset($_POST['check_Username'])){ //check username
            $user_name = $this->input->post('user_name', true);
            $response = $this->Admin_model->check_username_exist($user_name);
    
             print($response);
        }//check username
        if (isset($_POST['add_Consumers'])) {

            $output = array(
                'msg'		=>	303
            );
            echo json_encode($output);
        }
        if (isset($_POST['add_Consumer'])) { //add consumer start 


                //for consumer details 
                $Account_Number = $this->input->post('Account_Number',true);
                $First_name = $this->input->post('First_name',true);
                $Last_name = $this->input->post('Last_name',true);
                $purok_consumer = $this->input->post('purok_consumer',true);
                $avatar_consumer = $this->input->post('avatar_consumer',true);
                if (!empty($this->input->post('Email',true))) {
                    $Email = $this->input->post('Email',true);
                } else {
                    $Email = '';
                }
                
                $Contact_Number = $this->input->post('Contact_Number',true);
                $consumer_data = array(
                                    'account_id'   => $Account_Number, 
                                    'prk_id'       => $purok_consumer, 
                                    'con_fname'    => ucfirst($First_name), 
                                    'con_lname'    => ucfirst($Last_name), 
                                    'con_email'    => $Email, 
                                    'con_cpnumber' => $Contact_Number, 
                                    'con_avatar'   => $avatar_consumer, 
                                );

                $response_1 = $this->Admin_model->add_Consumer($consumer_data);
                
                // for consumer meter_number owner
                $meter_number = $this->input->post('meter_number',true);
                $meter_owner_data = array();
                foreach($meter_number as $key => $value){
                  $meter_owner_data[$key]['con_id'] = $response_1;
                  $meter_owner_data[$key]['meter_id'] = $value;
                }
                
                $response_2 = $this->Admin_model->add_meter_owner($meter_owner_data);

                //for consumer credentials
                $User_name = $this->input->post('User_name',true);
                $Password = $this->input->post('Password',true);
                $credentials_data = array(
                    'con_id'        => $response_1, 
                    'cre_username'  => $User_name, 
                    'cre_password'  => md5($Password), 
                    'cre_status'    => 1, 
                );

                $response_3 = $this->Admin_model->add_Credentials($credentials_data);

                if ($response_1 || $response_2 || $response_3) {
                    $result = 303;
                } else {
                    $result = 404;
                }
                
            
                $output = array(
                    'msg'		=>	$result
                );

            
                echo json_encode($output);
            } //add consumer end  

            if (isset($_POST['get_meter_number'])) {

                $con_id = $this->input->post('con_id',true);
                $response = $this->Admin_model->get_meter_number($con_id);
    
                $output = array(
                    'meter_num'		=>	$response
                );
                echo json_encode($output);
            }
            if (isset($_POST['bill_meter_id'])) {
                $meter_id = $this->input->post('meter_id',true);
                $response = $this->Admin_model->check_bill_meter($meter_id);
                if ($response == true) {
                    $result = 303;    
                }else{
                    $result = 404;
                }
                $output = array(
                    'msg'		=>	$result
                );
                echo json_encode($output);
            }
    
            if (isset($_POST['submit_bill'])) {
    
                date_default_timezone_set('Asia/Manila');
                $con_id = $this->input->post('con_id',true);
                $meter_id = $this->input->post('meter_id',true);

                if (!empty($this->input->post('pre_reading',true))) {
                    $pre_reading = $this->input->post('pre_reading',true);
                }
                $current_reading = $this->input->post('meter_reading',true);
                $monthly_bill = $this->input->post('monthly_bill',true);
                $arrears = $this->input->post('arrears',true);

                $this->db->select('*');
                $this->db->from('tb_bill');
                $this->db->where('con_id',$con_id);
                $this->db->where('meter_id',$meter_id);
                $this->db->order_by("bill_id", "desc");
                $this->db->limit(1);
                $query = $this->db->get();
                $row = $query->row_array();

                if ($query->num_rows() > 0) {
                    $previous_reading = $row['current_reading'];

                    $cubic_tmp = $current_reading - $row['current_reading'];
        
                    if ($cubic_tmp == 1 || $cubic_tmp == 2 || $cubic_tmp == 3 || $cubic_tmp == 4 ||
                    $cubic_tmp == 5 || $cubic_tmp == 6 || $cubic_tmp == 7 || $cubic_tmp == 8 ||
                    $cubic_tmp == 9 || $cubic_tmp == 10 || $cubic_tmp == 11 || $cubic_tmp == 12) {
    
                       $n = 100;
                       
                    }else{
    
                       $final_cubic = $cubic_tmp + 100 - 112;
                       $n = $final_cubic * 12 + 100;
                       
                       
                    }
                } else {
                    $previous_reading = $pre_reading;
                    //$n = 100;
                    $cubic_tmp = $current_reading - $previous_reading;
        
                    if ($cubic_tmp == 1 || $cubic_tmp == 2 || $cubic_tmp == 3 || $cubic_tmp == 4 ||
                    $cubic_tmp == 5 || $cubic_tmp == 6 || $cubic_tmp == 7 || $cubic_tmp == 8 ||
                    $cubic_tmp == 9 || $cubic_tmp == 10 || $cubic_tmp == 11 || $cubic_tmp == 12) {
    
                       $n = 100;
                       
                    }else{
    
                       $final_cubic = $cubic_tmp + 100 - 112;
                       $n = $final_cubic * 12 + 100;
                       
                       
                    }
                }
                




                $data = array(
    
                                'con_id'            => $con_id, 
                                'meter_id'          => $meter_id, 
                                'previous_reading'  => $previous_reading, 
                                'current_reading'   => $current_reading, 
                                'monthly_bill'      => $monthly_bill.'-01', 
                                'total_amount'      => $n + $arrears,
                                'arrears'           => $arrears,
                                'date_issued'       => date('Y-m-d g:ia')//date('F j, Y g:ia')
        
                            );
    

                //billing email receipt
                $this->db->select('*');
                $this->db->from('tb_consumers');
                $this->db->where('con_id',$con_id);
                $query2 = $this->db->get();
                $row2 = $query2->row_array();

                $this->db->select('*');
                $this->db->from('tb_meter_num');
                $this->db->where('meter_id',$meter_id);
                $query3 = $this->db->get();
                $row3 = $query3->row_array();

                //get bill no
                $this->db->select('COUNT(table_a.con_id) as bill_no');
                $this->db->from('tb_bill as table_a');
                $this->db->where('con_id', $con_id);
                $this->db->where('meter_id', $meter_id);
                $query4 = $this->db->get();
                $row4 = $query4->row_array();
                //get bill no
                    //send mail
                    $this->load->config('email');
                    $this->load->library('email');
                    $rec_date=date_create($monthly_bill);
                    
                    
                    $from = 'Water Billing KAPWACO';
                    $subject = "Water Bill for the month of ".date_format($rec_date,"F Y")." for Account no. ".$row2['account_id']."";
              
                    $message_old = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                      <title>RECEIPT</title>
                      <meta charset="utf-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1">
                    
                    </head>
                    <body>
                    
                    <div class="alert" style = " 
                    padding: 20px;
                    background-color: #D19C97;
                    color: black;
                    border-radius:20px;
                    font-family: Arial, Helvetica, sans-serif;
                    "> 
                    FROM:  <strong>Water Billing KAPWACO</strong>
                    <br>
                    <br>
                    <div style = "text-transform: uppercase;">
                    <h2 style = "text-align:center" >receipt</h2>
                   	<p><strong>'.$row2['con_fname'].' '.$row2['con_lname'].'</strong></p>
                    <hr>
                    <p>ACCOUNT NO. <strong>'.$row2['account_id'].'</strong></p>
                    <hr>
                    <p>METER NO. <strong>'.$row3['meter_num'].'</strong></p>
                    <hr>
                    <p>MONTH COVERED: <strong>'.date_format($rec_date,"F j, Y").'</strong></p>
                    <hr>
                    <p>DATE ISSUED: <strong>'.date('F j, Y g:ia').'</strong></p>
                    <hr>
                    <p>previous READING: <strong> '.$previous_reading.'</strong> | CURRENT READING: <strong> '.$current_reading.'</strong></p>
                    <hr>
                    <p>ARREARS: <strong>'.$arrears.'</strong></p>
                    <hr>
                    <p>CUBIC METER USED: <strong style = "text-transform: lowercase;">'.$current_reading - $previous_reading.' cubic foot</strong></p>
                    <hr>
                    <p>TOTAL AMOUNT TO PAY: <strong>PHP '.number_format($n + $arrears).'</strong></p>
                    <hr>
                    </div>
                    
                    <br>
                    <br>
                
                  </div>
                    
                    </body>
                    </html>
                    ';
                    if (empty($row4['bill_no'])) {
                        $bill_no = 1;
                    }else {
                        $bill_no = $row4['bill_no'] + 1;
                    }
                    $message = '<div class="alert" style = " 
                    padding: 10px;
                    background-color: #D19C97;
                    color: black;
                    border-radius:20px;
                    font-family: Arial, Helvetica, sans-serif;
                    font-size: 9px;
                    "> 
                    From:  <strong>Water Billing KAPWACO</strong>
                    <div style = "text-transform: uppercase;">
                    <h2 style = "text-align:center" >WATER BILL</h2>
                    <p>BILL NO.<strong> '.$bill_no.'</strong></p>
                    <hr>
                    <p>BILL PERIOD: <strong>'.date_format($rec_date,"M. j, Y").' to '.date_format($rec_date,"M. t, Y").'</strong></p>
                    <hr>
                     <p>Full NAME: <strong>'.$row2['con_fname'].' '.$row2['con_lname'].'</strong></p>
                    <hr>
                    <p>ACCOUNT NO. <strong>'.$row2['account_id'].'</strong></p>
                    <hr>
                    <p>METER NO. <strong>'.$row3['meter_num'].'</strong></p>
                    <hr>
                    <p>DATE ISSUED: <strong>'.date('M. j, Y g:ia').'</strong></p>
                    <hr>
                    <p>CURRENT READING: <strong>'.$current_reading.'</strong> | previous READING: <strong> '.$previous_reading.'</strong></p>
                    <hr>
                    <p>CUBIC <span style = "text-transform: lowercase;">ft</span> USED: <strong style = "text-transform: lowercase;">'.$current_reading - $previous_reading.'</strong></p>
                    <hr>
                    <p>ARREARS: <strong>'.$arrears.'</strong></p>
                    <hr>
                    <p>CURRENT BILL: <strong>'.$n.'</strong></p>
                    <hr>
                    <p>TOTAL AMOUNT TO PAY: <strong>PHP '.number_format($n + $arrears).'</strong></p>
                    <hr>
                    <p>DUE DATE: <strong>'.date('M. j, Y', strtotime("+14 days")).'</strong></p>
                    <hr>
                    <p>REMARKS: <strong>Please Pay the bill before due date.</strong></p>
                    <hr>
                    </div>
                ';
                    if (!empty($row2['con_email'])) {
                        $to_email = $row2['con_email'];
                    }else{
                        $to_email = 'kenext.ken@gmail.com';
                    }
                        $this->email->set_mailtype("html");
                        $this->email->set_crlf("\r\n");
                        $this->email->set_newline("\r\n");
                        $this->email->from($from);
                        $this->email->to($to_email);
                        $this->email->subject($subject);
                        $this->email->message($message);
                
            // if ($this->email->send()) {

                //billing email receipt end

                            
                if ($query->num_rows() == 0) { //if bill not exsit 
                    
                    
                    //$response = $this->Admin_model->submit_bill($data);
                    $check_previous_reading = $pre_reading;
                    if ($check_previous_reading < $current_reading) { //if bill dako pa sa current 
                        //$result = 303;
                        $response = $this->Admin_model->submit_bill($data);
        
                        if ($response) {
                            $this->email->send();
                            $result = 303;
                        } else {
                            $result = 404;
                        }
                        

                    }else{      //if bill dako pa ang prev
                        $result = 0;
                    }

                } else { //if bill exist
                    
                    $check_previous_reading = $row['current_reading'];
                    if ($check_previous_reading < $current_reading) { //if bill dako pa sa current 
                        //$result = 303;
                        $response = $this->Admin_model->submit_bill($data);
        
                        if ($response) {
                            $this->email->send();
                            $result = 303;
                        } else {
                            $result = 404;
                        }

                    }else{      //if bill dako pa ang prev
                        $result = 0;
                    }
                    
                }


            // } else {
            
            //     $result = 405;

            // }

                
            
                $output = array(
                    'msg'		=>	$result
                );
                echo json_encode($output);
            }

            if (isset($_POST['sample_dummy'])) {
                
        
                $response = 404;
                
                
                if ($response == 404) {
         
                    //send mail
                    $this->load->config('email');
                    $this->load->library('email');
                    
                    
                    $from = 'Water Billing KAPWACO';
                    $subject = "Water Bill for the month of December for Account no. #12312323";
              
                    $message = '<!DOCTYPE html>
                    <html lang="en">
                    <head>
                      <title>RECEIPT</title>
                      <meta charset="utf-8">
                      <meta name="viewport" content="width=device-width, initial-scale=1">
                    
                    </head>
                    <body>
                    
                    <div class="alert" style = " 
                    padding: 20px;
                    background-color: #D19C97;
                    color: black;
                    border-radius:20px;
                    font-family: Arial, Helvetica, sans-serif;
                    "> 
                    FROM:  <strong>Water Billing KAPWACO</strong>
                    <br>
                    <br>
                    <div style = "text-transform: uppercase;">
                    <h2 style = "text-align:center" >receipt</h2>
                   	<p><strong>KENNETH TANURON</strong></p>
                    <hr>
                    <p>ACCOUNT NO. <strong>#123123213</strong></p>
                    <hr>
                    <p>METER NO. <strong>0001</strong></p>
                    <hr>
                    <p>MONTH COVERED: <strong>DECEMBER 20 2023</strong></p>
                    <hr>
                    <p>DATE ISSUED: <strong>DECEMBER 20 2023 11:30am</strong></p>
                    <hr>
                    <p>previous READING: <strong> 151</strong> | CURRENT READING: <strong> 151</strong></p>
                    <hr>
                    <p>CUBIC METER USED: <strong style = "text-transform: lowercase;">1 cubic foot</strong></p>
                    <hr>
                    <p>TOTAL AMOUNT TO PAY: <strong>PHP 1000</strong></p>
                    <hr>
                    </div>
                    
                    <br>
                    <br>
                
                  </div>
                    
                    </body>
                    </html>
                    ';
                    $this->email->set_mailtype("html");
                    $this->email->set_crlf("\r\n");
                    $this->email->set_newline("\r\n");
                    $this->email->from($from);
                    $this->email->to('amajunriel.damalan@gmail.com');
                    $this->email->subject($subject);
                    $this->email->message($message);
            
                    if ($this->email->send()) {
        
                        echo $result = 'Success';
        
                    } else {
        
                        echo $result = '404';

                    }
                }
            }
            if (isset($_POST['deleteBill'])) { //deleteBill

                $bill_id = $this->input->post('bill_id',true);
               
                $response = $this->Admin_model->deleteBill($bill_id);

                if ($response == true) {
                    $result = 303;           
                }else{
                    $result = 404;        
                }
       
                $output = array(
                    'msg'		=>	$result
                );
        
                echo json_encode($output);
            }
            //payBill
            if (isset($_POST['payBill'])) { //payBill

                $bill_id = $this->input->post('bill_id',true);
               
                $response = $this->Admin_model->payBill($bill_id);

                if ($response == true) {
                    $result = 303;           
                }else{
                    $result = 404;        
                }
       
                $output = array(
                    'msg'		=>	$result
                );
        
                echo json_encode($output);
            }
            //check_meter_reading
            if (isset($_POST['check_meter_reading'])) {

                $con_id = $this->input->post('con_id',true);
                $current_reading = $this->input->post('meter_reading',true);
                
                $this->db->select('*');
                $this->db->from('tb_bill');
                $this->db->where('con_id',$con_id);
                //$this->db->where('meter_id',$meter_id);
                $this->db->order_by("bill_id", "desc");
                $this->db->limit(1);
                $query = $this->db->get();
                $row = $query->row_array();

                if ($query->num_rows() < 0) {
                    
                    $msg = 0;

                } else {
                    
                    $previous_reading = $row['current_reading'];
                    if ($previous_reading < $current_reading) {
                        $msg = 303;
                    }else{
                        $msg = 404;
                    }
                    
                }
    
                $output = array(
                    'msg'		=>	$msg
                );
                echo json_encode($output);
            }
            //disconnect_meter
            if (isset($_POST['disconnect_meter'])) {

                $meter_id = $this->input->post('meter_id',true);
                $response = $this->Admin_model->disconnect_meter($meter_id);

                if ($response) {
                    $result = 303;           
                }else{
                    $result = 404;        
                }
       
                $output = array(
                    'msg'		=>	$result
                );
        
                echo json_encode($output);
            }
            //activate_meter
            if (isset($_POST['activate_meter'])) {

                $meter_id = $this->input->post('meter_id',true);
                $response = $this->Admin_model->activate_meter($meter_id);

                if ($response) {
                    $result = 303;           
                }else{
                    $result = 404;        
                }
       
                $output = array(
                    'msg'		=>	$result
                );
        
                echo json_encode($output);
            }
            if (isset($_POST['update_profile'])) {


                date_default_timezone_set('Asia/Manila');
                $con_id = $this->input->post('con_id',true);
                $con_fname = $this->input->post('con_fname',true);
                $con_lname = $this->input->post('con_lname',true);

                if (!empty($this->input->post('con_email',true))) {
                    $con_email = $this->input->post('con_email',true);
                }else{
                    $con_email = '';
                }

                $con_cpnumber = $this->input->post('con_cpnumber',true);

                $data = array(
                                'con_id'        => $con_id, 
                                'con_fname'     => ucfirst($con_fname), 
                                'con_lname'     => ucfirst($con_lname), 
                                'con_email'     => $con_email, 
                                'con_cpnumber'  => $con_cpnumber
                            );

                $response = $this->Admin_model->update_profile($data);

                if ($response == true) {
                    $result = 303;           
                }else{
                    $result = 404;        
                }
       
                $output = array(
                    'msg'		=>	$result
                );
        
                echo json_encode($output);
       
           }

           //change_pass
            if (isset($_POST['change_pass'])) {


                date_default_timezone_set('Asia/Manila');
                $con_id = $this->input->post('con_id',true);
                $cre_password = $this->input->post('new_password',true);
               

                $data = array(
                                'con_id'           => $con_id, 
                                'cre_password'     => md5($cre_password)
                            );

                $response = $this->Admin_model->change_password_consumer($data);

                if ($response == true) {
                    $result = 303;           
                }else{
                    $result = 404;        
                }
       
                $output = array(
                    'msg'		=>	$result
                );
        
                echo json_encode($output);
       
           }
           //inactive
           if (isset($_POST['inactive'])) {


            date_default_timezone_set('Asia/Manila');
            $con_id = $this->input->post('con_id',true);
            $cre_status = 0;
           

            $data = array(
                            'con_id'           => $con_id, 
                            'cre_status'       => $cre_status
                        );

            $response = $this->Admin_model->inactive_consumer($data);

            if ($response == true) {
                $result = 303;           
            }else{
                $result = 404;        
            }
   
            $output = array(
                'msg'		=>	$result
            );
    
            echo json_encode($output);
   
         }

         if (isset($_POST['activate'])) { //active


            date_default_timezone_set('Asia/Manila');
            $con_id = $this->input->post('con_id',true);
            $cre_status = 1;
           

            $data = array(
                            'con_id'           => $con_id, 
                            'cre_status'       => $cre_status
                        );

            $response = $this->Admin_model->inactive_consumer($data);

            if ($response == true) {
                $result = 303;           
            }else{
                $result = 404;        
            }
   
            $output = array(
                'msg'		=>	$result
            );
    
            echo json_encode($output);
   
         }

            
            if (isset($_POST['all_consumer_bill'])) {  //fetch all_consumer_bill start
      
                date_default_timezone_set('Asia/Manila');

                $draw = intval($this->input->get("draw"));
                $start = intval($this->input->get("start"));
                $length = intval($this->input->get("length"));
                $payment_status = $this->input->post('payment_status',true);

                $this->db->select('
                table_a.*, 
                table_b.*, 
                table_c.*
                ');
                $this->db->from('tb_bill as table_a');
                $this->db->join('tb_consumers as table_b', 'table_a.con_id = table_b.con_id', 'inner');
                $this->db->join('tb_meter_num as table_c', 'table_a.meter_id = table_c.meter_id', 'inner');
                $this->db->where('table_a.payment_status', $payment_status);
                $this->db->order_by("table_a.bill_id", "desc");
                $query = $this->db->get();
                //query
               
                
                $data = [];
                $x = 1;
                
                foreach($query->result() as $r) {
                    $monthly_bill=date_create($r->monthly_bill);
                    $date_issued=date_create($r->date_issued);
                    //$per = 12; //per 12 cubic is 100 pesos
                    $cubic_tmp = $r->current_reading - $r->previous_reading;
        
                    if ($cubic_tmp == 1 || $cubic_tmp == 2 || $cubic_tmp == 3 || $cubic_tmp == 4 ||
                    $cubic_tmp == 5 || $cubic_tmp == 6 || $cubic_tmp == 7 || $cubic_tmp == 8 ||
                    $cubic_tmp == 9 || $cubic_tmp == 10 || $cubic_tmp == 11 || $cubic_tmp == 12) {

                       $n = 100;
                       
                    }else{

                       $final_cubic = $cubic_tmp + 100 - 112;
                       $n = $final_cubic * 12 + 100;
                       
                       
                    }

                    $date = date_create($r->date_issued);
                    $day = date_format($date,"Y-m-d");

                    // add 7 days to the date above
                    $NewDate = date('Y-m-d', strtotime($day . " +14 days"));

                    if (strtotime($NewDate) <= strtotime("now")) {
                        $disc = '<span class="badge badge-pill badge-danger"><i class="fas fa-exclamation-triangle"></i> Yes</span>';
                    }else{
                        $disc = '<span class="badge badge-pill badge-success"><i class="fas fa-check-circle"></i> No</span>';
                    }

                    if ($r->payment_status == 1) {
                        $status_payment = '<span class="badge badge-pill badge-success">Paid</span>';
                    }else{
                        $status_payment = '<span class="badge badge-pill badge-primary">Unpaid</span>';
                    }

                     $data[] = array(
                                "Select"            => "",
                                "#"                 => $x++,
                                "Notice_for_Dsc"    => $disc,
                                "Meter_Num"         => $r->meter_num,
                                "Full_Name"         => $r->con_fname.' '.$r->con_lname,
                                "Current_Reading"   => $r->current_reading,
                                "Previous_Reading"  => $r->previous_reading,
                                "Arrears"           => $r->arrears,
                                "Cubic_Meter_Used"  => $r->current_reading - $r->previous_reading.' ft³',
                                "Month_Covered"     => date_format($monthly_bill,"M. j, Y").' to '.date_format($monthly_bill,"M. t, Y"),
                                "Date_Issued"       => date_format($date_issued,"M. d Y g:ia"),
                                "Payment_Status"    => $status_payment,
                                "Total_Amount"      => '₱'.number_format($n + $r->arrears),
                                "Action"            => '<div class="btn-group dropleft">

                                <button type="button" class="btn btn-outline-info dropdown-toggle" data-toggle="dropdown"
                                  aria-haspopup="true" aria-expanded="false">
                                  <i class="fas fa-eye"></i>
                                </button>
        
                                <div class="dropdown-menu text-left pl-2 pr-2 bg-gray-200">
                                    
                                <div class = "bg-gray-100">
                                <a href="'.base_url().'Consumer-'.$r->con_id.'/'.trim($r->account_id, "#").'" id = "" class="dropdown-item btn-hover-view btn btn-outline-primary btn-lg p-1">
                                <span class="icon">
                                    <i class="fas fa-exclamation-circle"></i>
                                </span>
                                <span class="text">View Consumer</span>
                            </a>
                                <a href="#button" id = "'.$r->bill_id.'" class="dropdown-item btn-hover-success btn btn-outline-primary btn-lg p-1 payBillBtn"> 
                                    <span class="icon">
                                        <i class="fas fa-hand-holding-usd"></i>
                                    </span>
                                    <span class="text">Pay Bill</span>
                                </a>
                                <a href="#button" id = "'.$r->bill_id.'" class="d-none dropdown-item btn-hover-edit btn btn-outline-primary btn-lg p-1">
                                    <span class="icon">
                                        <i class="fas fa-exclamation-circle"></i>
                                    </span>
                                    <span class="text">Send Notice</span>
                                </a>
                                <a href="#button" id = "#" onclick="printInvoice('."'".base_url()."Print-Invoice-".$r->bill_id."'".')" class="dropdown-item btn-hover-edit btn btn-outline-primary btn-lg p-1">
                                    <span class="icon">
                                        <i class="fas fa-print"></i>
                                    </span>
                                    <span class="text">Print Invoice</span>
                                </a>
                                <a href="#button" id = "'.$r->bill_id.'" class="dropdown-item btn-hover-delete btn btn-outline-primary btn-lg p-1 deleteBillBtn">
                                    <span class="icon">
                                        <i class="fas fa-trash-alt"></i>
                                    </span>
                                    <span class="text">Delete Bill</span>
                                </a>
                                </div> 
        
                                </div>
        
                              </div>'
                     );
                }
          
          
                $result = array(
                         "draw" => $draw,
                           "recordsTotal" => $query->num_rows(),
                           "recordsFiltered" => $query->num_rows(),
                           "data" => $data
                      );
          
          
                echo json_encode($result);
                exit();
          
        
            }  //fetch all_consumer_bill end





        }else{
            show_404();
        }


    }//For consumer End

    public function get_sales($param = null){


        if ($param != null) {
           

            $response = $this->Admin_model->get_all_sales_summary($param);
  

            $result = array('manually' => $response['manually'], 'annually' => $response['annually']);

            echo json_encode($result);

        }

    }
    public function admin_cre(){

        
        if (isset($_POST['admin_cre'])) {



          
            $data['admin_uname'] = $this->input->post('admin_uname', true);
            $Old_Password = $this->input->post('Old_Password', true);
            $data['admin_pass'] = md5($this->input->post('New_Password', true));

            $this->db->select('*');
            $this->db->from('admin_credentials');
            $this->db->where('admin_pass',md5($Old_Password));
            $result = $this->db->get();
            $result->num_rows();

            if ($result->num_rows() == 1) {

                $response = $this->Admin_model->update_creden_admin($data);
                $result = 303;

            }else{

                $result = 404;
                    
            }

             $output = array(
                 'msg'		=>	$result
             );
     
            
             echo json_encode($output);

        }

    }//admin_cre

//Form end ----------------------------------------------------------------------->

} //class end ----------------------------------------------------------------------->




