<?php
defined('BASEPATH') OR exit('No direct script access allowed');
#[\AllowDynamicProperties]
class Consumer extends CI_Controller {


    function __construct() { 

        parent::__construct(); 
        $this->load->library('session');

    } 
//Pages Consumer START
	public function home($param = null)
	{

        if ($this->session->con_id || $this->session->con_access || $this->session->con_logged) {

            if ($param == 'Dashboard' || $param == 'Dues' || $param == 'Transaction' || $param == 'MyProfile') {
                $page_name = $param;
            }else{
                $page_name = 'Dashboard';
            }
     

            $data = array(

                'consumer_data' => $this->Consumer_model->consumer_info($con_id = $this->session->con_id),
                'Consumer_Info' => $this->Consumer_model->consumer_info_fetch($con_id = $this->session->con_id),
                'System'        => $this->Admin_model->system_title(),
                'Page_name'     => $page_name

            );
            if (
            !file_exists(APPPATH.'views/pages/consumer/home.php') || 
            !file_exists(APPPATH.'views/pages/consumer/dues.php') || 
            !file_exists(APPPATH.'views/pages/consumer/transaction.php')
            ){ 
                show_404(); 
            }

            $this->load->view('pages/templates/for_consumer/header', $data);
            $this->load->view('pages/templates/for_consumer/sidebar', $data);
            $this->load->view('pages/templates/for_consumer/topbar', $data);

            switch ($param) {
              case "Dashboard":     //Dashboard 
                $this->load->view('pages/consumer/home', $data);
                break;

              case "Dues":         //Dues         
                $this->load->view('pages/consumer/dues', $data);
                break;

              case "Transaction": //Transaction            
                $this->load->view('pages/consumer/transaction', $data);
                break;

              case "MyProfile": //Transaction            
                $this->load->view('pages/consumer/profile', $data);
                break;

              default:
                $this->load->view('pages/consumer/home', $data);
            }

            $this->load->view('pages/templates/for_consumer/footer', $data);

        }else{

               redirect(base_url().'Login');
                
        }

	}
//Pages Consumer END

//For Dues Datatables START
    public function consumer_data()
    {

        if (isset($_POST['dues'])) {
           
            $draw = intval($this->input->get("draw"));
            $start = intval($this->input->get("start"));
            $length = intval($this->input->get("length"));
            $condition = $this->input->post('dues',true);

            $response = $this->Consumer_model->consumer_dues($this->session->con_id,$condition);            
            $data = [];
            $x = 1;
            foreach($response['fetch'] as $r) {
                $monthly_bill=date_create($r->monthly_bill);
                if ($r->payment_status == 1) {
                    $status_payment = '<span class="badge badge-pill badge-success">Paid</span>';
                }else{
                    $status_payment = '<span class="badge badge-pill badge-primary">Unpaid</span>';
                }
                 $data[] = array(
                    
                            "#"                 => $x++,
                            "Meter_Num"         => $r->meter_num,
                            "Current_Reading"   => $r->current_reading,
                            "Previous_Reading"  => $r->previous_reading,
                            "Arrears"           => $r->arrears,
                            "Cubic_Meter_Used"  => $r->current_reading - $r->previous_reading.' ft³',
                            "Month_Covered"     => date_format($monthly_bill,"M. j, Y").' to '.date_format($monthly_bill,"M. t, Y"),
                            "Date_Issued"       => $r->date_issued,
                            "Payment_Status"    => $status_payment,
                            "Total_Amount"      => '<button type="button" class="btn btn-success btn-sm">₱'.number_format($r->total_amount).'</button>',
                            "Option"            => '
                            
                                                <button type="button" class="btn btn-outline-info">
                                                <i class="fas fa-eye"></i>
                                                </button>
            
                                                    '
                           
                 );
            }
      
      
            $result = array(
                        "draw"              => $draw,
                        "recordsTotal"      => $response['num_rows'],
                        "recordsFiltered"   => $response['num_rows'],
                        "data"              => $data
                  );
      
      
            echo json_encode($result);
            exit();
      
        }
    }
//For Dues Datatables END
        public function monthly_payment(){

            $meter_id = $this->uri->segment(3);
            $year = $this->uri->segment(4);


            $response = $this->Consumer_model->consumer_monthly_payment($meter_id,$year);            

            $output = array(
                    'monthly' => $response['manually'], 
                    'yearly' => $response['annually'],
                    'total_cubic' => $response['total_cubic']
                    );

            echo json_encode($output);
            exit();
        }
//error 404
	public function error_404()
	{
        $this->load->view('errors/error_404');

    }
    

    public function for_consumer(){

        if (isset($_POST['update_profile'])) {


            date_default_timezone_set('Asia/Manila');
            $con_id = $this->input->post('con_id',true);
            $con_fname = $this->input->post('con_fname',true);
            $con_lname = $this->input->post('con_lname',true);

            if (!empty($this->input->post('con_email',true))) {
                $con_email = $this->input->post('con_email',true);
            }else{
                $con_email = '';
            }

            $con_cpnumber = $this->input->post('con_cpnumber',true);

            $data = array(
                            'con_id'        => $con_id, 
                            'con_fname'     => ucfirst($con_fname), 
                            'con_lname'     => ucfirst($con_lname), 
                            'con_email'     => $con_email, 
                            'con_cpnumber'  => $con_cpnumber
                        );

            $response = $this->Admin_model->update_profile($data);

            if ($response == true) {
                $result = 303;           
            }else{
                $result = 404;        
            }
   
            $output = array(
                'msg'		=>	$result
            );
    
            echo json_encode($output);
   
       }

       if (isset($_POST['change_creden'])) {

        $data['con_id'] = $this->input->post('con_id', true);
        $data['cre_username'] = $this->input->post('username', true);
        $Old_Password = $this->input->post('old_password', true);
        $data['cre_password'] = md5($this->input->post('new_password', true));

        $this->db->select('*');
        $this->db->from('tb_credentials');
        $this->db->where('con_id',$this->input->post('con_id', true));
        $this->db->where('cre_password',md5($Old_Password));
        $result = $this->db->get();
        $result->num_rows();

        if ($result->num_rows() == 1) {

            $response = $this->Consumer_model->update_creden_consumer($data);
            $result = 303;

        }else{

            $result = 404;
                
        }

         $output = array(
             'msg'		=>	$result
         );
 
        
         echo json_encode($output);

    }

    }
    //ends of pages class
}
