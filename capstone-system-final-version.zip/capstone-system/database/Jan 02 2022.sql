-- phpMyAdmin SQL Dump
-- version 5.1.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Jan 02, 2023 at 02:13 AM
-- Server version: 10.4.21-MariaDB
-- PHP Version: 8.0.10

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `water_billing`
--

-- --------------------------------------------------------

--
-- Table structure for table `admin_credentials`
--

CREATE TABLE `admin_credentials` (
  `admin_id` int(11) NOT NULL,
  `admin_name` varchar(200) NOT NULL,
  `admin_profile` varchar(200) NOT NULL,
  `admin_uname` varchar(200) NOT NULL,
  `admin_pass` varchar(500) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `admin_credentials`
--

INSERT INTO `admin_credentials` (`admin_id`, `admin_name`, `admin_profile`, `admin_uname`, `admin_pass`) VALUES
(1, 'Administrator', 'img/logo/waterbilling_logo.png', 'admin', '202cb962ac59075b964b07152d234b70');

-- --------------------------------------------------------

--
-- Table structure for table `months_table`
--

CREATE TABLE `months_table` (
  `id` int(11) NOT NULL,
  `month_name` varchar(45) DEFAULT NULL
) ENGINE=InnoDB DEFAULT CHARSET=latin1;

--
-- Dumping data for table `months_table`
--

INSERT INTO `months_table` (`id`, `month_name`) VALUES
(1, 'January'),
(2, 'February'),
(3, 'March'),
(4, 'April'),
(5, 'May'),
(6, 'June'),
(7, 'July'),
(8, 'August'),
(9, 'September'),
(10, 'October'),
(11, 'November'),
(12, 'December');

-- --------------------------------------------------------

--
-- Table structure for table `system_title`
--

CREATE TABLE `system_title` (
  `id_title` int(11) NOT NULL,
  `system_name` varchar(100) NOT NULL,
  `system_title` varchar(100) NOT NULL,
  `system_logo` varchar(100) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `system_title`
--

INSERT INTO `system_title` (`id_title`, `system_name`, `system_title`, `system_logo`) VALUES
(1, 'Water Billing', '', 'img/logo/waterbilling_logo.png');

-- --------------------------------------------------------

--
-- Table structure for table `tb_bill`
--

CREATE TABLE `tb_bill` (
  `bill_id` int(11) NOT NULL,
  `con_id` int(11) NOT NULL,
  `meter_id` int(11) NOT NULL,
  `previous_reading` int(11) NOT NULL,
  `current_reading` int(11) NOT NULL,
  `monthly_bill` varchar(300) NOT NULL,
  `total_amount` int(11) NOT NULL,
  `arrears` int(11) NOT NULL,
  `date_issued` varchar(300) NOT NULL,
  `payment_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_bill`
--

INSERT INTO `tb_bill` (`bill_id`, `con_id`, `meter_id`, `previous_reading`, `current_reading`, `monthly_bill`, `total_amount`, `arrears`, `date_issued`, `payment_status`) VALUES
(11, 32, 11, 100, 101, '2023-01', 100, 0, '2022-12-31 4:21am', 1),
(12, 32, 11, 101, 150, '2023-02', 544, 0, '2022-12-31 4:23am', 1),
(13, 34, 6, 99, 100, '2023-01', 100, 0, '2023-01-01 11:10am', 0),
(14, 37, 7, 99, 100, '2023-01', 100, 0, '2023-01-01 11:11am', 0),
(15, 38, 13, 100, 101, '2023-01', 100, 0, '2023-01-01 11:14am', 1),
(16, 40, 9, 100, 101, '2023-01', 100, 0, '2023-01-01 11:32am', 1),
(17, 41, 10, 99, 100, '2023-01', 100, 0, '2023-01-01 12:05pm', 1),
(18, 41, 10, 100, 101, '2023-02', 100, 0, '2023-01-01 12:06pm', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_consumers`
--

CREATE TABLE `tb_consumers` (
  `con_id` int(11) NOT NULL,
  `prk_id` int(11) NOT NULL,
  `account_id` varchar(300) NOT NULL,
  `con_fname` varchar(300) NOT NULL,
  `con_lname` varchar(300) NOT NULL,
  `con_email` varchar(300) NOT NULL,
  `con_cpnumber` varchar(30) NOT NULL,
  `con_avatar` varchar(500) NOT NULL,
  `sorting_num` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_consumers`
--

INSERT INTO `tb_consumers` (`con_id`, `prk_id`, `account_id`, `con_fname`, `con_lname`, `con_email`, `con_cpnumber`, `con_avatar`, `sorting_num`) VALUES
(30, 20, '#1672307103', 'Kenneth', 'Tanuron', 'kenneth.tanuron@gmail.com', '09361776112', 'Boy', 3),
(32, 1, '#1672307230', 'Aj', 'Damalan', '', '09361776112', 'Man', 9),
(34, 20, '#1672308626', 'Itachis', 'Uchiha', 'kenneth.tanuron@gmail.com', '09361776112', 'Boy', 2),
(37, 1, '#1672310612751', 'Gaara', 'Uchiha', '', '09361776112', 'Boy', 8),
(38, 20, '#1672310722481', 'Nauruto', 'Uzumaki', '', '09361776112', 'Boy', 1),
(39, 21, '#1672331680817', 'Eren', 'Yeager', '', '09361776112', 'Boy', 0),
(40, 21, '#1672412459824', 'Madam', 'Lueren', '', '09361776112', 'Girl', 0),
(41, 18, '#1672412734941', 'Sylwyn', 'Zayas', '', '09361776112', 'Boy', 0);

-- --------------------------------------------------------

--
-- Table structure for table `tb_credentials`
--

CREATE TABLE `tb_credentials` (
  `cre_id` int(11) NOT NULL,
  `con_id` int(11) NOT NULL,
  `cre_username` varchar(300) NOT NULL,
  `cre_password` varchar(500) NOT NULL,
  `cre_status` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_credentials`
--

INSERT INTO `tb_credentials` (`cre_id`, `con_id`, `cre_username`, `cre_password`, `cre_status`) VALUES
(1, 30, 'ken123', 'af974cf3ae8a5bf92832a864766f5b6c', 0),
(2, 32, 'aj123', 'f7938fdfb2a02d400416050e66441a32', 1),
(3, 34, 'itachi123', '202cb962ac59075b964b07152d234b70', 1),
(6, 37, 'gaara123', '05e68101b416e55847ac808a67f4a54d', 1),
(7, 38, 'naruto123', '884ecc7ac05cb5d52aa970f523a3b7e6', 1),
(8, 39, 'eren123', '291b74dec227f7ba5d04a1db8e99588b', 0),
(9, 40, 'madam123', 'bb693abdab1c0a0cf2736c132c2b02c0', 1),
(10, 41, 'zayas123', 'b5e19303dbce972c66031702f173c246', 1);

-- --------------------------------------------------------

--
-- Table structure for table `tb_meter_num`
--

CREATE TABLE `tb_meter_num` (
  `meter_id` int(11) NOT NULL,
  `meter_num` varchar(300) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_meter_num`
--

INSERT INTO `tb_meter_num` (`meter_id`, `meter_num`) VALUES
(4, '0001'),
(5, '0002'),
(6, '0003'),
(7, '0004'),
(8, '0005'),
(9, '0006'),
(10, '0007'),
(11, '0008'),
(12, '0009'),
(13, '0010'),
(14, '0011'),
(15, '0012'),
(16, '0013'),
(17, '0014'),
(18, '0015'),
(19, '0016'),
(20, '0017'),
(23, '0018'),
(24, '0019'),
(25, '0020'),
(26, '0021'),
(27, '0022'),
(28, '0023'),
(29, '0024'),
(31, '0025'),
(30, '0026'),
(32, '1027'),
(33, '1028');

-- --------------------------------------------------------

--
-- Table structure for table `tb_owner_meter`
--

CREATE TABLE `tb_owner_meter` (
  `owner_id` int(11) NOT NULL,
  `con_id` int(11) NOT NULL,
  `meter_id` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_owner_meter`
--

INSERT INTO `tb_owner_meter` (`owner_id`, `con_id`, `meter_id`) VALUES
(1, 30, 4),
(2, 30, 5),
(3, 32, 11),
(4, 34, 6),
(8, 37, 7),
(9, 38, 13),
(10, 39, 8),
(11, 40, 9),
(12, 41, 10);

-- --------------------------------------------------------

--
-- Table structure for table `tb_prk`
--

CREATE TABLE `tb_prk` (
  `prk_id` int(11) NOT NULL,
  `prk_name` varchar(300) NOT NULL,
  `prk_sort` int(11) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4;

--
-- Dumping data for table `tb_prk`
--

INSERT INTO `tb_prk` (`prk_id`, `prk_name`, `prk_sort`) VALUES
(1, 'Sapong', 1),
(18, 'Purok 6', 2),
(20, 'Purok 10 Mamiguis', 3),
(21, 'Purok 7', 4);

--
-- Indexes for dumped tables
--

--
-- Indexes for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  ADD PRIMARY KEY (`admin_id`),
  ADD UNIQUE KEY `UQ_admin_id` (`admin_id`);

--
-- Indexes for table `months_table`
--
ALTER TABLE `months_table`
  ADD UNIQUE KEY `months_table_id_uindex` (`id`);

--
-- Indexes for table `system_title`
--
ALTER TABLE `system_title`
  ADD PRIMARY KEY (`id_title`);

--
-- Indexes for table `tb_bill`
--
ALTER TABLE `tb_bill`
  ADD PRIMARY KEY (`bill_id`),
  ADD UNIQUE KEY `UQ_bill_id` (`bill_id`),
  ADD KEY `FK_tb_consumers_TO_tb_bill` (`con_id`),
  ADD KEY `FK_tb_meter_num_TO_tb_bill` (`meter_id`);

--
-- Indexes for table `tb_consumers`
--
ALTER TABLE `tb_consumers`
  ADD PRIMARY KEY (`con_id`),
  ADD UNIQUE KEY `UQ_con_id` (`con_id`),
  ADD UNIQUE KEY `UQ_account_id` (`account_id`),
  ADD KEY `FK_tb_prk_TO_tb_consumers` (`prk_id`);

--
-- Indexes for table `tb_credentials`
--
ALTER TABLE `tb_credentials`
  ADD PRIMARY KEY (`cre_id`),
  ADD UNIQUE KEY `UQ_cre_id` (`cre_id`),
  ADD UNIQUE KEY `UQ_cre_username` (`cre_username`),
  ADD KEY `FK_tb_consumers_TO_tb_credentials` (`con_id`);

--
-- Indexes for table `tb_meter_num`
--
ALTER TABLE `tb_meter_num`
  ADD PRIMARY KEY (`meter_id`),
  ADD UNIQUE KEY `UQ_meter_id` (`meter_id`),
  ADD UNIQUE KEY `UQ_meter_num` (`meter_num`);

--
-- Indexes for table `tb_owner_meter`
--
ALTER TABLE `tb_owner_meter`
  ADD PRIMARY KEY (`owner_id`),
  ADD UNIQUE KEY `UQ_owner_id` (`owner_id`),
  ADD KEY `FK_tb_consumers_TO_tb_owner_meter` (`con_id`),
  ADD KEY `FK_tb_meter_num_TO_tb_owner_meter` (`meter_id`);

--
-- Indexes for table `tb_prk`
--
ALTER TABLE `tb_prk`
  ADD PRIMARY KEY (`prk_id`),
  ADD UNIQUE KEY `UQ_prk_id` (`prk_id`),
  ADD UNIQUE KEY `UQ_prk_name` (`prk_name`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `admin_credentials`
--
ALTER TABLE `admin_credentials`
  MODIFY `admin_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `months_table`
--
ALTER TABLE `months_table`
  MODIFY `id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `system_title`
--
ALTER TABLE `system_title`
  MODIFY `id_title` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=2;

--
-- AUTO_INCREMENT for table `tb_bill`
--
ALTER TABLE `tb_bill`
  MODIFY `bill_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=19;

--
-- AUTO_INCREMENT for table `tb_consumers`
--
ALTER TABLE `tb_consumers`
  MODIFY `con_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=42;

--
-- AUTO_INCREMENT for table `tb_credentials`
--
ALTER TABLE `tb_credentials`
  MODIFY `cre_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=11;

--
-- AUTO_INCREMENT for table `tb_meter_num`
--
ALTER TABLE `tb_meter_num`
  MODIFY `meter_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=34;

--
-- AUTO_INCREMENT for table `tb_owner_meter`
--
ALTER TABLE `tb_owner_meter`
  MODIFY `owner_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=13;

--
-- AUTO_INCREMENT for table `tb_prk`
--
ALTER TABLE `tb_prk`
  MODIFY `prk_id` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=23;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `tb_bill`
--
ALTER TABLE `tb_bill`
  ADD CONSTRAINT `FK_tb_consumers_TO_tb_bill` FOREIGN KEY (`con_id`) REFERENCES `tb_consumers` (`con_id`),
  ADD CONSTRAINT `FK_tb_meter_num_TO_tb_bill` FOREIGN KEY (`meter_id`) REFERENCES `tb_meter_num` (`meter_id`);

--
-- Constraints for table `tb_consumers`
--
ALTER TABLE `tb_consumers`
  ADD CONSTRAINT `FK_tb_prk_TO_tb_consumers` FOREIGN KEY (`prk_id`) REFERENCES `tb_prk` (`prk_id`);

--
-- Constraints for table `tb_credentials`
--
ALTER TABLE `tb_credentials`
  ADD CONSTRAINT `FK_tb_consumers_TO_tb_credentials` FOREIGN KEY (`con_id`) REFERENCES `tb_consumers` (`con_id`);

--
-- Constraints for table `tb_owner_meter`
--
ALTER TABLE `tb_owner_meter`
  ADD CONSTRAINT `FK_tb_consumers_TO_tb_owner_meter` FOREIGN KEY (`con_id`) REFERENCES `tb_consumers` (`con_id`),
  ADD CONSTRAINT `FK_tb_meter_num_TO_tb_owner_meter` FOREIGN KEY (`meter_id`) REFERENCES `tb_meter_num` (`meter_id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
